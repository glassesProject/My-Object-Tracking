from dataclasses import dataclass
import enum

class TagColor(enum.Enum):
    """
    Enum class for predefined tag colors.
    """
    Gold = 0
    """
    Represents the color Gold
    """
    LightSeaGreen = 1
    """
    Represents the color LightSeaGreen
    """
    SkyBlue = 2
    """
    Represents the color SkyBlue
    """
    RoyalBlue = 3
    """
    Represents the color RoyalBlue
    """
    Tomato = 4
    """
    Represents the color Tomato
    """
    Pink = 5
    """
    Represents the color Pink
    """
    Purple = 6
    """
    Represents the color Purple
    """
    DarkGray = 7
    """
    Represents the color DarkGray
    """
    Black = 8
    """
    Represents the color Black"""
    White = 9
    """
    Represents the color White
    """

@dataclass
class AddTagRequest:
    """
    Dataclass representing a request to add a tag with a specified brush and timestamp.
    """
    name: str
    """ The name of the tag. """
    description: str
    """ The description of the tag. """
    timestamp: int
    """ The tag's timestamp in milliseconds. """
    brush: str
    """ The brush color of the tag. """

    def __init__(self, name, desc, timestamp, color: TagColor):
        """ Initializes the AddTagRequest instance with the specified values. """
        self.name = name
        self.description = desc
        self.timestamp = round(timestamp)
        self.brush = Brush.get(color)

class Brush:
    """
    Class representing Brush color of predefined tag colors.

    Examples:
    ```python
    >>> color = Brush.get(TagColor.Gold)
    >>> print(color)
    '#FFC700'
    ```
    """
    preset = [
              '#FFC700',
              '#00A1A7',
              '#62D6FB',
              '#2E6CF6',
              '#E04444',
              '#FF7CBB',
              '#784587',
              '#8E8C8C',
              '#000000',
              '#FFFFFF'
            ]
    """
    Preset colors for the brush.
    """
    
    @classmethod
    def get(cls, color: TagColor):
        """
        Returns the text representation of the brush color for the specified TagColor.
        """
        return cls.preset[color.value]
