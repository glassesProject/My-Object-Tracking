import asyncio
from dataclasses import dataclass
import weakref

from ..common_models import Camera
from ..streaming.video_stream import VideoStream


@dataclass
class EyeCameraStreamCollector:
    """
    Class responsible for collecting frames from each eye's camera.
    To collect frames from both eyes, create two instances of this class, one for each eye.

    Arguments:
    ----------
    - **url** : str
        The URL of the camera stream.
    - **camera** : Camera
        The camera type: Camera.LEFT_EYE or Camera.RIGHT_EYE.
    - **data_mgr** : weakref.ReferenceType
        A weak reference to the data manager object, which is used to store the collected frames.
    """
    _url: str
    _camera: Camera
    _data_mgr: weakref.ReferenceType

    def start(self):
        """
        Starts the collection of eye camera frames.
        """
        self._streaming_task = asyncio.create_task(self._collect_data())
    
    async def _collect_data(self):
        async with VideoStream(self._url) as streamer:
            async for frame in streamer.get_data():
                data_mgr = self._data_mgr()
                match self._camera:
                    case Camera.LEFT_EYE:
                        data_mgr.add_left_eye_frame(frame)
                    case Camera.RIGHT_EYE:
                        data_mgr.add_right_eye_frame(frame)
                    case _:
                        raise ValueError(f"Invalid camera type: {self._camera}")
