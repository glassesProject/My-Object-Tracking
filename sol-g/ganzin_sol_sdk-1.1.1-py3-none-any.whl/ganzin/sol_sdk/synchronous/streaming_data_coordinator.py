from collections import deque
import threading

class StreamingDataCoordinator:
    """
    Class for coordinating streaming data from various sources.

    This class manages the storage and retrieval of streaming data such as
    scene frames, gaze data, and left and right eye frames. It uses deques to
    store the data and threading events to signal the availability of new data.
    """
    def __init__(self, duration_seconds=3):
        """
        Initializes the instance with the specified duration.
        
        Arguments:
        ----------
        **duration_seconds** (int): The duration in seconds for which
            the data stores will retain frames. This value determines the
            maximum length of the deques based on the frame rate. For example,
            a duration of 3 seconds will store up to 90 frames for
            scene frames (30fps) and up to 360 frames for gaze and
            left eye frames (120fps).
        """
        # data stores
        self._scene_frame_store = deque(maxlen=duration_seconds*30) # 30fps
        self._gaze_store = deque(maxlen=duration_seconds*120) # 120fps
        self._left_eye_frame_store = deque(maxlen=duration_seconds*120) # 120fps
        self._right_eye_frame_store = deque(maxlen=duration_seconds*120) # 120fps

        # events
        self._event_new_gaze_available = threading.Event()
        self._event_new_scene_data_available = threading.Event()
        self._event_new_left_eye_data_available = threading.Event()
        self._event_new_right_eye_data_available = threading.Event()

# gaze
    def add_gaze(self, gaze):
        """
        Adds a gaze data object to the gaze store.
        """
        self._gaze_store.append(gaze)
        self._event_new_gaze_available.set()

    def pop_all_gazes(self):
        """
        Pops all gaze data objects from the gaze store.

        Returns:
        ------
            list: The list of gaze data objects.
        """
        all_gazes = list(self._gaze_store)
        self._gaze_store.clear()
        return all_gazes

    def wait_for_gazes(self, timeout=None):
        """
        Waits for new gaze data to be available.

        Arguments:
        ----------
            timeout: The maximum time to wait for new gaze data.

        Returns:
        -------
            list: The list of gaze data objects.
        """
        self._event_new_gaze_available.clear()
        if self._event_new_gaze_available.wait(timeout=timeout):
            return self.pop_all_gazes()
        return None
    
    def clear_gaze_store(self):
        """
        Clears the gaze store.
        """
        self._gaze_store.clear()

# scene camera frame
    def add_scene_frame(self, frame):
        """
        Adds a scene camera frame to the scene frame store.
        """
        self._scene_frame_store.append(frame)
        self._event_new_scene_data_available.set()

    def pop_all_scene_frames(self):
        """
        Pops all scene camera frames from the scene frame store.
        
        Returns:
        -------
            list: The list of frame data objects.
        """
        all_frames = list(self._scene_frame_store)
        self._scene_frame_store.clear()
        return all_frames

    def wait_for_scene_frames(self, timeout=None):
        """
        Waits for new scene camera frames to be available.

        Arguments:
        ----------
            timeout: The maximum time to wait for new scene camera frames.

        Returns:
        -------
            list: The list of frame data objects.
        """
        self._event_new_scene_data_available.clear()
        if self._event_new_scene_data_available.wait(timeout=timeout):
            return self.pop_all_scene_frames()
        return None
    
    def clear_scene_frame_store(self):
        """
        Clears the scene frame store.
        """
        self._scene_frame_store.clear()

# left eye frame
    def add_left_eye_frame(self, frame):
        """
        Adds a left eye camera frame to the left eye frame store.
        """
        self._left_eye_frame_store.append(frame)
        self._event_new_left_eye_data_available.set()

    def pop_all_left_eye_frames(self):
        """
        Pops all left eye camera frames from the left eye frame store.

        Returns:
        -------
            list: The list of frame data objects.
        """
        frames = list(self._left_eye_frame_store)
        self._left_eye_frame_store.clear()
        return frames
    
    def wait_for_left_eye_frames(self, timeout=None):
        """
        Waits for new left eye camera frames to be available.
        
        Arguments:
        ----------
            timeout: The maximum time to wait for new left eye camera frames.
        
        Returns:
        -------
            list: The list of frame data objects.
        """
        self._event_new_left_eye_data_available.clear()
        if self._event_new_left_eye_data_available.wait(timeout=timeout):
            return self.pop_all_left_eye_frames()
        return None
    
    def clear_left_eye_frame_store(self):
        """
        Clears the left eye frame store.
        """
        self._left_eye_frame_store.clear()
    
# right eye frame
    def add_right_eye_frame(self, frame):
        """
        Adds a right eye camera frame to the right eye frame store.
        """
        self._right_eye_frame_store.append(frame)
        self._event_new_right_eye_data_available.set()

    def pop_all_right_eye_frames(self):
        """
        Pops all right eye camera frames from the right eye frame store.

        Returns:
        -------
            list: The list of frame data objects.
        """
        frames = list(self._right_eye_frame_store)
        self._right_eye_frame_store.clear()
        return frames

    def wait_for_right_eye_frames(self, timeout=None):
        """
        Waits for new right eye camera frames to be available.

        Arguments:
        ----------
            timeout: The maximum time to wait for new right eye camera frames.
        
        Returns:
        -------
            list: The list of frame data objects.
        """
        self._event_new_right_eye_data_available.clear()
        if self._event_new_right_eye_data_available.wait(timeout=timeout):
            return self.pop_all_right_eye_frames()
        return None

    def clear_right_eye_frame_store(self):
        """
        Clears the right eye frame store.
        """
        self._right_eye_frame_store.clear()
