import asyncio
from dataclasses import dataclass
import weakref

from ..streaming.video_stream import VideoStream


@dataclass
class SceneCameraStreamCollector:
    """
    Class to handle the collection of scene camera frames.

    Arguments:
    ----------
    - **url** : str
        The URL of the scene camera stream.
    - **data_mgr** : weakref.ReferenceType
        A weak reference to the data manager object, which is used to store the collected frames.
    """
    _url: str
    _data_mgr: weakref.ReferenceType

    def start(self):
        """
        Starts the collection of scene camera frames.
        """
        self._streaming_task = asyncio.create_task(self._collect_data())

    async def _collect_data(self):
        async with VideoStream(self._url) as streamer:
            async for frame in streamer.get_data():
                data_mgr = self._data_mgr()
                data_mgr.add_scene_frame(frame)
