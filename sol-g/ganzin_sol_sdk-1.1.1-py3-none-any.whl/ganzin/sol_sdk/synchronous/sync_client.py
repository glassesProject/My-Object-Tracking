import asyncio
from http import HTTPStatus
import json
import urllib3
import urllib3.util
import weakref

from ..common_models import ApiStatus, Camera
from .eye_camera_stream_collector import EyeCameraStreamCollector
from ..api import Api
from ..responses import (
    CaptureResponse, LockResponse, StatusResponse, RecordResponse, TagResponse,
    VersionResponse, SceneCameraParamResponse,
    lockResponseMapper, recordResponseMapper, versionResponseMapper,
    captureResponseMapper, statusResponseMapper, sceneCameraParamResponseMapper,
    parse_json_to_object
)
from ..requests import AddTagRequest
from ..utils import TaskRunningThread, UpdateListener, validate_sdk_version
from .gaze_stream_collector import GazeStreamCollector
from .models import StreamingMode
from ..streaming.protocol import streaming_scheme
from ..streaming.gaze_stream import GazeData
from ..streaming.video_stream import FrameData
from .streaming_data_coordinator import StreamingDataCoordinator
from ..time_sync import TimeSync, TimeSyncResult
from .scene_camera_stream_collector import SceneCameraStreamCollector


class SyncClient:
    """
    Synchronous client for interacting with the server.
    """
    def __init__(self, address, port, rtsp_port=8086):
        """
        Initializes the client with the specified address and port.

        Arguments:
        ----------
        - **address** : str
            The IP address of the server.
        - **port** : int
            The port number of the server.
        - **rtsp_port** : int, optional
            The RTSP port number of the server. Default is 8086.
        """
        self._uri = f"{address}:{port}"
        self._rtsp_uri = f"{streaming_scheme}://{address}:{rtsp_port}/?camera="
        timeout = urllib3.util.Timeout(connect=2.0, read=7.0)
        self._http = urllib3.PoolManager(timeout=timeout)
        self._data = StreamingDataCoordinator()
        remote_api_version = self.get_version().remote_api_version
        validate_sdk_version(remote_api_version)

    def _get_uri(self, api: Api, protocol="http"):
        return f"{protocol}://{self._uri}/api/{api}"
    
    def get_version(self) -> VersionResponse:
        """
        Retrieves the SDK version that the server is expected to support.

        Returns:
        --------
            VersionResponse: The response object containing the SDK version.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.get_version()
        print(resp.remote_api_version)
        ```
        """
        resp = self._http.request("GET", self._get_uri(Api.GET_VERSION.value))
        return json.loads(resp.data, object_hook=versionResponseMapper)

    def get_status(self) -> StatusResponse:
        """
        Retrieves the status of the server.

        Returns:
        --------
            StatusResponse: The response object containing the status information.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.get_status()
        print(resp.device_name)
        ```
        """
        resp = self._http.request("GET", self._get_uri(Api.GET_STATUS.value))
        return json.loads(resp.data, object_hook=statusResponseMapper)

    def get_scene_camera_param(self) -> SceneCameraParamResponse:
        """
        Retrieves the scene camera parameters.
        
        Returns:
        --------
            SceneCameraParamResponse: The response object containing the status, message, and optionally the scene camera parameters.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.get_scene_camera_param()
        print(resp.camera_param.intrinsic)
        ```
        """
        resp = self._http.request("GET", self._get_uri(Api.GET_SCENE_CAMERA_PARAM.value))
        if resp.status == HTTPStatus.OK:
            return json.loads(resp.data, object_hook=sceneCameraParamResponseMapper)
        else:
            data = resp.json()
            return SceneCameraParamResponse(ApiStatus(data["status"]), data["message"], None)

    def begin_record(self) -> RecordResponse:
        """
        Send a request to the server to initiate recording.

        Returns:
        --------
            RecordResponse: The response object containing the status of the recording.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.begin_record()
        print(resp.status)
        resp = sc.end_record()
        print(resp.status)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.BEGIN_RECORD.value))
        return json.loads(resp.data, object_hook=recordResponseMapper)

    def end_record(self) -> RecordResponse:
        """
        Send a request to the server to stop recording.

        Returns:
        --------
            RecordResponse: The response object containing the status of the recording.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.begin_record()
        print(resp.status)
        resp = sc.end_record()
        print(resp.status)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.END_RECORD.value))
        return json.loads(resp.data, object_hook=recordResponseMapper)
    
    def add_tag(self, request: AddTagRequest) -> TagResponse:
        """
        Send a request to the server to add the specified tag.

        Arguments:
        ----------
            request (AddTagRequest): The request object containing tag information.

        Returns:
        --------
            TagResponse: The response object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        color = TagColor.LightSeaGreen
        req = AddTagRequest('right moment', 'description', 1719387152014, color)
        resp = sc.add_tag(req)
        print(f'Add tag result? {resp}')
        ```
        """
        resp = self._http.request(
            "POST",
            self._get_uri(Api.ADD_TAG.value),
            json=vars(request)
        )
        return parse_json_to_object(resp.data, TagResponse)

    def capture(self) -> CaptureResponse:
        """
        Request server to capture frame and gaze.

        The response includes the frame image and the gaze data at that moment.

        Returns:
        --------
            CaptureResponse: The response object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.capture()
        result = CaptureResult.from_raw(resp.result)
        print(f'timestamp = {result.timestamp}')
        print(f'gaze: x = {result.gaze_data.combined.gaze_2d.x}, y = {result.gaze_data.combined.gaze_2d.y}')
        with open("image_captured.jpg", "wb") as file:
            file.write(result.scene_image)
            print(f'Saved image to "{file.name}"') 
        ```
        """
        resp = self._http.request("GET", self._get_uri(Api.CAPTURE.value))
        return json.loads(resp.data, object_hook=captureResponseMapper)
    
    def lock(self) -> LockResponse:
        """
        Send a request to the server to switch the "Ganzin Chronus" app to locked mode.
        
        Returns:
        --------
            LockResponse: The response object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.lock()
        print(resp.status)
        resp = sc.unlock()
        print(resp.status)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.LOCK.value))
        return json.loads(resp.data, object_hook=lockResponseMapper)
    
    def unlock(self) -> LockResponse:
        """
        Send a request to the server to unlock the "Ganzin Chronus" app.
    
        Returns:
        --------
            LockResponse: The response object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.lock()
        print(resp.status)
        resp = sc.unlock()
        print(resp.status)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.UNLOCK.value))
        return json.loads(resp.data, object_hook=lockResponseMapper)

    def listen_to_update(self, callback) -> TaskRunningThread:
        """
        Listen to the server for updates.

        This method connects to the server using a WebSocket connection.
        The client will be updated in the following scenarios:
        - Start or stop recording
        - Lock or unlock the device
        - Turn on or off eye encoding
        - Change in mobile battery status
        - When another client connects to the server to receive status updates

        Arguments:
        ----------
            callback (Callable): The callback function to be called when an update is received.

        Returns:
        --------
            TaskRunningThread: The thread object that is listening to updates.

        Example:
        --------
        ```python
        def callback(data):
            print(data)

        sc = SyncClient(address, port)
        thread = sc.listen_to_update(callback)
        thread.start()
        ```
        """
        cancel_event = asyncio.Event()

        async def _listen_task():
            ws_uri = self._get_uri(Api.GET_STATUS.value, "ws")
            listener = UpdateListener(ws_uri, callback)
            await listener.begin_listen()
            await cancel_event.wait()
            await listener.end_listen()

        return TaskRunningThread(_listen_task, cancel_event)

    def create_streaming_thread(self, mode: StreamingMode) -> TaskRunningThread:
        """
        Creates a thread that runs the streaming task.

        Arguments:
        ----------
            mode (StreamingMode): Specifies the streaming mode to be used,
            enabling users to activate only the necessary streams.
            If GAZE_SCENE is specified, both gaze and scene camera streams will be activated.

        Returns:
        --------
            TaskRunningThread: The thread object that is running the streaming task.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        # Create a streaming thread that streams gaze and scene camera data.
        th = sc.create_streaming_thread(StreamingMode.GAZE_SCENE)
        th.start()

        try:
            while True:
                frame_data = sc.get_scene_frames_from_streaming(timeout=5.0)
                frame_datum = frame_data[-1] # get the last frame
                buffer = frame_datum.get_buffer()
                gazes = sc.get_gazes_from_streaming(timeout=5.0)
                gaze = find_nearest_timestamp_match(frame_datum.get_timestamp(), gazes)

                center = (int(gaze.combined.gaze_2d.x), int(gaze.combined.gaze_2d.y))
                radius = 30
                bgr_color = (255, 255, 0)
                thickness = 5
                cv2.circle(buffer, center, radius, bgr_color, thickness)

                cv2.imshow('Press "q" to exit', buffer)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            th.cancel()
            th.join()
            print('Stopped')
        ```
        """
        cancel_event = asyncio.Event()
           
        async def _recv_task():
            try:
                if mode & StreamingMode.GAZE:
                    gaze_url = self._rtsp_uri + Camera.GAZE.value
                    gaze_stream = GazeStreamCollector(gaze_url, weakref.ref(self._data))
                    gaze_stream.start()

                if mode & StreamingMode.SCENE:
                    scene_url = self._rtsp_uri + Camera.SCENE.value
                    scene_stream = SceneCameraStreamCollector(scene_url, weakref.ref(self._data))
                    scene_stream.start()

                if mode & StreamingMode.EYES:
                    left_eye_url = self._rtsp_uri + Camera.LEFT_EYE.value
                    left_eye_stream = EyeCameraStreamCollector(left_eye_url, Camera.LEFT_EYE, weakref.ref(self._data))
                    left_eye_stream.start()

                    right_eye_url = self._rtsp_uri + Camera.RIGHT_EYE.value
                    right_eye_stream = EyeCameraStreamCollector(right_eye_url, Camera.RIGHT_EYE, weakref.ref(self._data))
                    right_eye_stream.start()

                await cancel_event.wait()
            except Exception as ex:
                print(ex)
        return TaskRunningThread(_recv_task, cancel_event)

    def get_gazes_from_streaming(self, timeout) -> list[GazeData]:
        """
        Retrieves the gaze data from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the gaze data.

        Returns:
        --------
            list[GazeData]: The list of gaze data objects.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        th = sc.create_streaming_thread(StreamingMode.GAZE_SCENE)
        th.start()

        try:
            while True:
                frame_data = sc.get_scene_frames_from_streaming(timeout=5.0)
                frame_datum = frame_data[-1] # get the last frame
                buffer = frame_datum.get_buffer()
                # Retrieve the gaze data from the streaming thread.
                gazes = sc.get_gazes_from_streaming(timeout=5.0)
                gaze = find_nearest_timestamp_match(frame_datum.get_timestamp(), gazes)

                center = (int(gaze.combined.gaze_2d.x), int(gaze.combined.gaze_2d.y))
                radius = 30
                bgr_color = (255, 255, 0)
                thickness = 5
                cv2.circle(buffer, center, radius, bgr_color, thickness)

                cv2.imshow('Press "q" to exit', buffer)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            th.cancel()
            th.join()
            print('Stopped')
        ```
        """
        gazes = self._data.pop_all_gazes()
        if gazes:
            return gazes
        else:
            return self._data.wait_for_gazes(timeout)

    def get_scene_frames_from_streaming(self, timeout) -> FrameData:
        """
        Retrieves the scene camera frames from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the scene camera frames.

        Returns:
        --------
            FrameData: The frame data object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        th = sc.create_streaming_thread(StreamingMode.SCENE)
        th.start()

        try:
            while True:
                # Retrieve the scene camera frames from the streaming thread.
                frame_data = sc.get_scene_frames_from_streaming(timeout=5.0)
                frame_datum = frame_data[-1] # get the last frame
                cv2.imshow('Press "q" to quit', frame_datum.get_buffer())
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            print('Stopped')

        th.cancel()
        th.join()
        ```
        """
        frames = self._data.pop_all_scene_frames()
        if frames:
            return frames
        else:
            return self._data.wait_for_scene_frames(timeout)

    def get_left_eye_frames_from_streaming(self, timeout=None) -> list[FrameData]:
        """
        Retrieves the left eye camera frames from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the left eye camera frames.

        Returns:
        --------
            list[FrameData]: The list of frame data objects.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        th = sc.create_streaming_thread(StreamingMode.EYES)
        th.start()

        try:
            while True:
                # Retrieve the left eye camera frames from the streaming thread.
                left_eye_data = sc.get_left_eye_frames_from_streaming(timeout=5.0)
                right_eye_data = sc.get_right_eye_frames_from_streaming()
                left_eye_datum = left_eye_data[0]
                right_eye_datum = find_nearest_timestamp_match(left_eye_datum.get_timestamp(), right_eye_data)
                combined_img = numpy.hstack((left_eye_datum.get_buffer(), right_eye_datum.get_buffer()))
                
                cv2.imshow('Press "q" to quit', combined_img)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            print('Stopped')

        th.cancel()
        th.join()
        ```
        """
        frames = self._data.pop_all_left_eye_frames()
        if frames:
            return frames
        else:
            return self._data.wait_for_left_eye_frames(timeout)
        
    def get_right_eye_frames_from_streaming(self, timeout=None) -> list[FrameData]:
        """
        Retrieves the right eye camera frames from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the right eye camera frames.
        
        Returns:
        --------
            list[FrameData]: The list of frame data objects.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        th = sc.create_streaming_thread(StreamingMode.EYES)
        th.start()

        try:
            while True:
                left_eye_data = sc.get_left_eye_frames_from_streaming(timeout=5.0)
                # Retrieve the right eye camera frames from the streaming thread.
                right_eye_data = sc.get_right_eye_frames_from_streaming()
                left_eye_datum = left_eye_data[0]
                right_eye_datum = find_nearest_timestamp_match(left_eye_datum.get_timestamp(), right_eye_data)
                combined_img = numpy.hstack((left_eye_datum.get_buffer(), right_eye_datum.get_buffer()))
                
                cv2.imshow('Press "q" to quit', combined_img)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            print('Stopped')

        th.cancel()
        th.join()
        ```
        """
        frames = self._data.pop_all_right_eye_frames()
        if frames:
            return frames
        else:
            return self._data.wait_for_right_eye_frames(timeout)

    def run_time_sync(self, number_of_polls = 60) -> TimeSyncResult:
        """
        Run time synchronization with the server.

        Arguments:
        ----------
            number_of_polls: The number of time synchronization polls to perform.

        Returns:
        --------
            TimeSyncResult: The result of the time synchronization polls.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        result = sc.run_time_sync(number_of_polls=80)
        print(f"Time Offset Mean: {result.time_offset.mean}")
        print(f"Round Trip Mean: {result.round_trip.mean}")
        ```
        """
        url = self._get_uri(Api.TIME_SYNC.value, "ws")
        time_sync = TimeSync(url)
        return asyncio.run(time_sync.polls_multiple_times(number_of_polls))
