import asyncio
from struct import unpack

from aiortsp.rtsp.errors import RTSPError
from aiortsp.transport.tcp import TCPTransport
from aiortsp.rtcp.parser import RTCP, SR, RTCP_TYPES


TS_OFFSET_1900_MS = 2208988800000
"""
@private
Offset in milliseconds between the NTP epoch (1900-01-01) and the Unix epoch (1970-01-01)
"""

def _ntp_to_ts_ms(seconds: int, fraction: int) -> float:
    """
    Convert NTP seconds and fraction to a timestamp in milliseconds.

    Args:
        seconds (int): The seconds part of the NTP timestamp.
        fraction (int): The fractional part of the NTP timestamp.

    Returns:
        float: The corresponding timestamp in milliseconds, adjusted for the NTP epoch offset.
    """
    ntp_ms = (seconds + fraction / 0x100000000) * 1000
    return ntp_ms - TS_OFFSET_1900_MS

def _sr_unpack_ntp_ts_in_ms(px, pt, p_len, data):
    """
    Unpack an RTCP Sender Report packet and convert NTP timestamps to milliseconds.
    """
    ssrc, ntp1, ntp2, rtp_ts, pkt_count, byte_count = unpack('!IIIIII', data[:24])
    ntp_ts = _ntp_to_ts_ms(ntp1, ntp2)
    reports = SR.parse_reports(px, data[24:])
    return SR(ssrc=ssrc, ntp=ntp_ts, ts=rtp_ts, pkt_count=pkt_count, byte_count=byte_count, reports=reports)

def _custom_rtcp_unpack(data: bytes) -> 'RTCP':
    """
    Parse a buffer into an RTCP instance
    """
    packets = []

    # Iterate on every packet found
    while data:

        # Unpack the header before deciding type
        px, pt, p_len = unpack('!BBH', data[:4])

        # Check version
        if px & 0xC0 != 0x80:
            raise ValueError('RTP version must be 2')

        # Check type exists
        if pt not in RTCP_TYPES:
            raise ValueError(f'Not an RTCP packet type: {pt}')

        # Split current bytes and bytes from next packet
        payload_length = 4 + p_len * 4
        if payload_length > len(data):
            raise ValueError(f'RTCP Packet truncated ({payload_length} > {len(data)})')

        payload, data = data[4:payload_length], data[payload_length:]

        if px & 0x20:
            # There is some padding to be removed
            payload = payload[:len(payload)-payload[-1]]

        if RTCP_TYPES[pt] is SR:
            packets.append(_sr_unpack_ntp_ts_in_ms(px, pt, p_len, payload))
        else:
            # Compound packet, unpack it
            packets.append(RTCP_TYPES[pt].unpack(px, pt, p_len, payload))

    return RTCP(packets=packets)

class CustomTCPTransport(TCPTransport):
    """
    Custom TCP Transport that does not check the interleaved header on the SETUP response.
    """
    def on_transport_response(self, headers: dict):
        if 'transport' not in headers:
            raise RTSPError('error on SETUP: Transport not found')
        
        # fields = self.parse_transport_fields(headers['transport'])
        # assert fields.get('interleaved') == f'{self.rtp_idx}-{self.rtcp_idx}', 'invalid returned interleaved header'
    
    def handle_rtcp_data(self, data: bytes):
        """
        Overrides the default RTCP handling to obtain NTP timestamps in milliseconds.
        """
        rtcp = _custom_rtcp_unpack(data)
        self.logger.debug('received RTCP report: %s', rtcp)

        self.stats.handle_rtcp(rtcp)

        if self._rtcp_loop is None:
            # This is the first packet ever!
            self._rtcp_loop = asyncio.ensure_future(self.rtcp_loop())

        for client in self.clients:
            try:
                client.handle_rtcp(rtcp)
            except Exception as ex:  # pylint: disable=broad-except
                self.logger.error('error on RTCP client callback: %r', ex)
