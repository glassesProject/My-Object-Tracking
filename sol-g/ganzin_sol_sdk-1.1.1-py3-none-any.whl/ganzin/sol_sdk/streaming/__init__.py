"""
This package includes classes for various types of streams used in the SDK.
"""

__all__ = ['gaze_stream', 'video_stream', 'base_stream']
