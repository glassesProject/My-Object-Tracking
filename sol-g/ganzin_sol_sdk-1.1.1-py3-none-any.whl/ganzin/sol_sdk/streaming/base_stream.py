from abc import ABC, abstractmethod
from aiortsp.rtcp.parser import SR
from .custom_rtsp_reader import CustomRTSPReader

class RtcpInfo:
    """
    @private
    Class to store information from an RTCP packet, including NTP and RTP timestamps.
    """
    def __init__(self, ntp_ts, rtp_ts):
        self.ntp_ts = ntp_ts
        self.rtp_ts = rtp_ts

class BaseStream(CustomRTSPReader, ABC):
    """
    Base class for handling raw data from RTSP streams.

    This class extends RTSPReader to provide a framework for processing
    RTSP streams. It handles RTCP packets to adjust timestamps and 
    provides an abstract method for handling raw data.
    """
    def __init__(self, *args, **kwargs):
        self._rtcp_info: RtcpInfo = None
        super().__init__(*args, **kwargs)

    def handle_rtcp(self, rtcp):
        """
        Handle incoming RTCP packets.

        Arguments:
        ----------
            rtcp: The RTCP packet containing multiple sub-packets.

        This method iterates over the sub-packets in the RTCP packet and if it finds
        a Sender Report (SR) packet, it records the timestamp difference.
        """
        for pkt in rtcp.packets:
            if isinstance(pkt, SR):
                self._store_rtcp_info(pkt)

    async def get_data(self):
        """
        Asynchronously get data packets from the RTSP stream.

        This method iterates over the packets in the RTSP stream, adjusts their timestamps,
        and yields the processed data.

        Yields:
        -------
            The processed data with adjusted timestamps.
        """
        async for pkt in self.iter_packets():
            timestamp = self._get_adjusted_timestamp(pkt)
            if timestamp is None:
                continue

            data = self.handle_raw_data(pkt.data, timestamp)
            if data is not None:
                yield data
    
    @abstractmethod
    def handle_raw_data(self, data: bytes, timestamp):
        """
        Abstract method to handle raw data.

        Arguments:
        ----------
            - data (bytes): The raw data from the packet.
            - timestamp: The adjusted timestamp for the data.

        This method must be implemented by subclasses to process the raw data.
        """
        pass

    def _store_rtcp_info(self, pkt):
        self._rtcp_info = RtcpInfo(ntp_ts=pkt.ntp, rtp_ts=pkt.ts)

    def _get_adjusted_timestamp(self, pkt):
        if self._rtcp_info is None:
            return None
        else:
            return self._get_rtp_timestamp_ms(pkt)
        
    def _get_rtp_timestamp_ms(self, pkt):
        dt =  pkt.ts - self._rtcp_info.rtp_ts
        clock_rate = self.session.sdp["medias"][0]["attributes"]["rtpmap"]["clockRate"]
        timestamp = (dt / clock_rate) * 1000 + self._rtcp_info.ntp_ts
        return int(timestamp)
