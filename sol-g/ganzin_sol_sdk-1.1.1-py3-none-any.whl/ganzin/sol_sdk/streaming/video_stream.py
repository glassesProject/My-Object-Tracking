import av
from dataclasses import dataclass
import numpy
import base64
from struct import unpack
from .base_stream import BaseStream

@dataclass
class FrameData:
    """
    Dataclass representing video frame data.
    """
    _frame: av.VideoFrame
    _timestamp: float

    def get_buffer(self) -> numpy.ndarray[numpy.uint8]:
        """
        Returns the frame data as a numpy array.
        """
        return self._frame.to_ndarray(format="bgr24")

    def get_timestamp(self):
        """
        Returns the Unix timestamp of the video frame data, representing the
        total number of milliseconds elapsed since 00:00:00 UTC on January 1, 1970.
        """
        return self._timestamp

class VideoStream(BaseStream):
    """
    Class to handle video streams.
    """
    def __init__(self, *args, **kwargs):
        self._codec = None
        self._encoding = None
        self._sprop_parameters = None
        self._timestamp = None
        super().__init__(*args, **kwargs)

    def handle_raw_data(self, data: bytes, timestamp):
        """
        @private
        Processes raw data and decodes it into frame data.

        This function handles raw byte data, initializes the codec if it is not already set,
        and decodes the data into frames. If the codec is not initialized, it creates the codec
        and parses the necessary parameters. Once the codec is ready, it processes the raw data
        to extract frames and associates them with the provided timestamp.

        Args:
            data (bytes): The raw byte data to be processed.
            timestamp: The timestamp associated with the raw data.

        Returns:
            FrameData: The decoded frame data along with the timestamp, or None if an error occurs
            during codec initialization.
        """
        if not self._codec:
            try:
                self._codec = self._create_codec()
                for param in self._get_sprop_parameters():
                    self._codec.parse(param)
            except (KeyError, IndexError) as error:
                return None
        else:
            for pkt in self._codec.parse(self._get_nal_payload(data)):
                for frame in self._codec.decode(pkt):
                    return FrameData(frame, self._timestamp)
            self._timestamp = timestamp

    def _create_codec(self):
        return av.CodecContext.create(self._get_encoding(), "r")

    def _get_encoding(self):
        if self._encoding is None:
            self._encoding = self.session.sdp["medias"][0]["attributes"]["rtpmap"]["encoding"].lower()
        return self._encoding

    def _get_sprop_parameters(self):
        if self._sprop_parameters is None:
            parameter_sets = self.session.sdp["medias"][0]["attributes"]["fmtp"]["sprop-parameter-sets"]
            parts = [part for part in parameter_sets.split(",")]
            param_sets = [base64.b64decode(part) for part in parts]
            self._sprop_parameters = [self._get_nal_payload(param) for param in param_sets]
        return self._sprop_parameters

    def _get_nal_payload(self, data):
        start_bytes = b'\x00\x00\x00\x01'

        payload_header = unpack('!B', data[:1])[0]
        is_forbidden_bit_one = payload_header & 0b10000000
        if is_forbidden_bit_one:
            raise Exception('Forbidden_zero_bit not zero')
        
        payload_offset = 0
        nal_unit_type = payload_header & 0b00011111
        if nal_unit_type == 28:
            payload_offset = 2
            fu_header = unpack('!B', data[1:2])[0]
            if fu_header & 0b10000000:
                p1 = payload_header & 0b11000000
                p2 = fu_header & 0b00011111
                return start_bytes + bytes((p1 + p2, )) + data[payload_offset:]
            else:
                return data[payload_offset:]
                
        return start_bytes + data[payload_offset:]
