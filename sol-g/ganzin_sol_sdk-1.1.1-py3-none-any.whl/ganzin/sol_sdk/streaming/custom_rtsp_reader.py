import asyncio
from time import time
from urllib.parse import urlparse

from aiortsp.rtsp.reader import RTSPReader
from aiortsp.transport.udp import UDPTransport
from aiortsp.rtsp.session import RTSPMediaSession, sanitize_rtsp_url
from .custom_rtsp_connection import CustomRTSPConnection
from .custom_tcp_transport import CustomTCPTransport


class CustomRTSPReader(RTSPReader):
    """
    Custom RTSP Reader that uses a custom RTSP connection and transport.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def transport_for_scheme(self, scheme: str):
        """Return transport type based on scheme"""
        transport_class = {
            'rtsp': UDPTransport,
            'rtspt': CustomTCPTransport
        }.get(scheme)

        if not transport_class:
            raise ValueError(f'invalid URL scheme `{scheme}`')

        return transport_class

    async def run_stream(self):
        """
        Setup and play stream, and ensure it stays on.
        """
        self.logger.info('try loading stream %s', sanitize_rtsp_url(self.media_url))

        p_url = urlparse(self.media_url)
        async with CustomRTSPConnection(
                p_url.hostname, p_url.port or 554,
                p_url.username, p_url.password,
                logger=self.logger, timeout=self.timeout
        ) as conn:
            self.logger.info('connected!')

            transport_class = self.transport_for_scheme(p_url.scheme)

            async with transport_class(conn, logger=self.logger, timeout=self.timeout) as transport:
                async with RTSPMediaSession(conn, self.media_url, transport=transport, logger=self.logger) as sess:

                    self.on_ready(conn, transport, sess)

                    self.logger.info('playing stream...')
                    await sess.play()

                    try:
                        last_keep_alive = time()
                        while conn.running and transport.running:
                            # Check keep alive
                            now = time()
                            if (now - last_keep_alive) > sess.session_keepalive:
                                await sess.keep_alive()
                                last_keep_alive = now

                            await asyncio.sleep(1)

                    except asyncio.CancelledError:
                        self.logger.info('stopping stream...')
                        raise
