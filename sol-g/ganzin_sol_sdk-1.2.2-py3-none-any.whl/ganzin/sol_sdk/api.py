from enum import Enum

class Api(Enum):
    """
    Enum class representing various API endpoints.
    """

    GET_VERSION = "version"
    """
    Endpoint for getting the version information.
    """

    GET_STATUS = "status"
    """
    Endpoint for getting the status information.
    """

    GET_SCENE_CAMERA_PARAM = "scene_camera_param"
    """
    Endpoint for getting the scene camera parameters.
    """

    BEGIN_RECORD = "recording_start"
    """
    Endpoint for starting a recording.
    """

    END_RECORD = "recording_stop"
    """
    Endpoint for stopping a recording.
    """

    ADD_TAG = "tag"
    """
    Endpoint for adding a tag.
    """

    CAPTURE = "capture_scene_with_gaze"
    """
    Endpoint for capturing a video stream frame from the scene camera with gaze data.
    """

    TIME_SYNC = "time_sync"
    """
    Endpoint for synchronizing time.
    """

    LOCK = "lock"
    """
    Endpoint for locking the device.
    """

    UNLOCK = "unlock"
    """
    Endpoint for unlocking the device.
    """
