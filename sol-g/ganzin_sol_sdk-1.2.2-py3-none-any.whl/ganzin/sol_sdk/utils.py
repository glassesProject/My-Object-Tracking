import asyncio
from importlib import metadata
import re
from threading import Thread
from typing import List, TypeVar
import weakref
import websockets
import time

from .common_models import SemanticVersion

T = TypeVar('T')

class TaskRunningThread(Thread):
    """
    A thread class that runs an asyncio task and supports cancellation.
    """

    def __init__(self, task, cancel_event: asyncio.Event):
        """
        Initializes the thread with the task and the cancel event.
        """
        super().__init__()
        self._task = task
        self._cancel_event = cancel_event

    def run(self):
        """
        Starts the asyncio event loop and runs the task.

        This method is called when the thread is started. It initializes the asyncio
        event loop and runs the provided task.
        """
        asyncio.run(self._thread_func(
            obj_ref = weakref.ref(self),
            task = self._task
        ))

    @staticmethod
    async def _thread_func(
        obj_ref: weakref.ReferenceType,
        task
    ):
        obj_ref()._loop = asyncio.get_event_loop()
        await task()
        obj_ref()._loop = None

    def cancel(self):
        """
        Cancels the running task by setting the cancel event.
        """
        if self._loop:
            self._loop.call_soon_threadsafe(self._set_cancel_event)

    def _set_cancel_event(self):
        self._cancel_event.set()

class UpdateListener:
    """
    A class that listens for updates from a WebSocket server.
    """
    def __init__(self, uri, callback):
        """
        Initializes the UpdateListener with the specified URI and
        callback function, which is called when an update is received.
        """
        self._uri = uri
        """ The URI of the WebSocket server to connect to. """
        self._callback = callback
        """ The callback function to handle the received messages. """

    async def begin_listen(self):
        """ Starts the listening task asynchronously. """
        self._update_task = asyncio.create_task(self.listen_func())

    async def end_listen(self):
        """  Cancels the listening task if it is running and waits for it to finish."""
        if self._update_task is not None:
            self._update_task.cancel()

            try:
                await self._update_task
            except asyncio.CancelledError:
                pass
            self._update_task = None
    
    async def listen_func(self):
        """
        The main listening function that connects to the WebSocket server
        and listens for updates.
        """
        async for msg in collect_update(self._uri):
            self._callback(msg)

async def collect_update(uri):
    """
    Asynchronously collect updates from a WebSocket server.
    """
    async for websocket in websockets.connect(uri):
        try:
            async for msg in websocket:
                yield msg
        except websockets.ConnectionClosed:
            print("Connection closed. Retry connect...")
            continue
        except asyncio.CancelledError:
            print("Task canceled")
            break

def get_timestamp_ms():
    """
    Returns the current timestamp in milliseconds.

    This function retrieves the current time in nanoseconds using `time.time_ns()`
    and converts it to milliseconds by dividing by 1,000,000.

    Returns
    -------
    int
        The current timestamp in milliseconds.
    """
    return time.time_ns() // 1_000_000

def find_nearest_timestamp_match(reference_timestamp, data_list: List[T]) -> T:
    """
    Finds the data object in the list with the nearest timestamp to the reference timestamp.
    """
    nearest_match = min(data_list, key=lambda x: abs(x.get_timestamp() - reference_timestamp))
    return nearest_match

def validate_sdk_version(api_version) -> bool:
    """
    Validates the SDK version against the specified API version.

    Parameters:
    ----------
    api_version : str
        The version of the API to validate against.

    Returns:
    -------
    bool
        True if the SDK version is compatible with the API version, False otherwise.

    Raises:
    -------
    Exception
        If the SDK version is outdated or newer in terms of major versions.

    This function retrieves the current SDK version of the "ganzin-sol-sdk" package
    and uses an internal validation function to check if it is compatible with the
    specified API version.
    """
    sdk_version = metadata.version("ganzin-sol-sdk")
    return _validate_sdk_version_internal(sdk_version, api_version)

def _validate_sdk_version_internal(sdk_version, api_version) -> bool:
    '''
    >>> _validate_sdk_version_internal('1.0.0', '1.0.0')
    True
    >>> _validate_sdk_version_internal('0.0.2', '1.0.0')
    Traceback (most recent call last):
    Exception: Your SDK version is outdated, please update to 1.0.0.
    >>> _validate_sdk_version_internal('2.0.0', '1.0.0')
    Traceback (most recent call last):
    Exception: Your SDK version is newer, please update the Ganzin Chronus.
    >>> _validate_sdk_version_internal('1.1.0', '1.0.0')
    Warning: Your SDK version is newer in terms of minor versions, please update the Ganzin Chronus.
    False
    >>> _validate_sdk_version_internal('1.0.0', '1.1.0')
    Warning: Your SDK version is outdated in terms of minor versions, please update to 1.1.0.
    False
    >>> _validate_sdk_version_internal('1.0.1', '1.0.0')
    Note: Your SDK version is newer in terms of patch versions.
    False
    >>> _validate_sdk_version_internal('1.0.0', '1.0.1')
    Note: Your SDK version is outdated in terms of patch versions, please update to 1.0.1.
    False
    '''

    sdk_version = parse_semantic_version(sdk_version)
    api_version = parse_semantic_version(api_version)

    equal, is_sdk_newer, difference = compare_semantic_version(sdk_version, api_version)
    if equal:
        return True
    else:
        if is_sdk_newer:
            msg1 = '{}Your SDK version is newer{}'
            msg2 = ', please update the Ganzin Chronus.'
            if difference == 'major':
                raise Exception(msg1.format('', '') + msg2)
            elif difference == 'minor':
                print(msg1.format('Warning: ', ' in terms of minor versions') + msg2)
                return False
            elif difference == 'patch':
                print(msg1.format('Note: ', ' in terms of patch versions') + '.')
                return False
        else:
            msg = '{}Your SDK version is outdated{}, please update to {}.'
            if difference == 'major':
                raise Exception(msg.format('', '', api_version))
            elif difference == 'minor':
                print(msg.format('Warning: ', ' in terms of minor versions', api_version))
                return False
            elif difference == 'patch':
                print(msg.format('Note: ', ' in terms of patch versions', api_version))
                return False
            
def parse_semantic_version(version):
    """
    Parse a semantic version string into a SemanticVersion object
    which contains major, minor, and patch versions.
    """
    pattern = r"^(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)$"
    match = re.match(pattern, version)
    if match:
        return SemanticVersion(
            major=int(match.group("major")),
            minor=int(match.group("minor")),
            patch=int(match.group("patch"))
        )
    else:
        raise ValueError(f"Invalid semantic version: {version}")
    
def compare_semantic_version(v1: SemanticVersion, v2: SemanticVersion):
    '''
    Compare two semantic versions.

    Args:
        v1 (SemanticVersion): The first semantic version to compare.
        v2 (SemanticVersion): The second semantic version to compare.

    Returns:
        tuple: A tuple containing three elements:
            - bool: True if the versions are equal, False otherwise.
            - bool or None: If not equal, True if v1 is greater, False if v1 is lesser,
              None if versions are equal.
            - str or None: The part of the version that differs ('major', 'minor', 'patch'),
              or None if versions are equal.
    Raises:
        ValueError: If the comparison result of the two arguments is unexpected.
    '''
    if v1 == v2:
        return (True, None, None)
    else:
        if v1.major > v2.major:
            return (False, True, 'major')
        elif v1.major < v2.major:
            return (False, False, 'major')
        else:
            if v1.minor > v2.minor:
                return (False, True, 'minor')
            elif v1.minor < v2.minor:
                return (False, False, 'minor')
            else:
                if v1.patch > v2.patch:
                    return (False, True, 'patch')
                elif v1.patch < v2.patch:
                    return (False, False, 'patch')
                else:
                    raise ValueError(f"Invalid version comparison: {v1}, {v2}")

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
