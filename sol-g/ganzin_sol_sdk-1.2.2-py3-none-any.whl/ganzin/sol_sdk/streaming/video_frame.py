from dataclasses import dataclass

import av
import numpy


@dataclass
class VideoFrame:
    """
    Dataclass representing video frame data.
    """
    _frame: av.VideoFrame
    _timestamp: float

    def get_buffer(self) -> numpy.ndarray[numpy.uint8]:
        """
        Returns the frame data as a numpy array.
        """
        return self._frame.to_ndarray(format="bgr24")

    def get_timestamp(self):
        """
        Returns the Unix timestamp of the video frame data, representing the
        total number of milliseconds elapsed since 00:00:00 UTC on January 1, 1970.
        """
        return self._timestamp