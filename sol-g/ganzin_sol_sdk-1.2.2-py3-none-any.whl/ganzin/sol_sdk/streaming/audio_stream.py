from .audio_mixin import AudioMixin
from .base_stream import BaseStream
from .media_type import MediaType


class AudioStream(BaseStream, AudioMixin):
    """
    Represents an audio stream.

    This class is used to handle the audio stream, including
    processing the raw data packets and managing the audio
    configurations.
    """
    def __init__(self, *args, **kwargs):
        self._audio_media_info = None
        self._audio_config = None
        self._audio_codec = None
        self._audio_size_length = None
        self._timestamp = None
        self._requested_media = MediaType.AUDIO
        super().__init__(*args, **kwargs, media_types = { 0: "audio" })

    def handle_raw_data(self, packet, timestamp, track_id):
        """
        Handles raw data packets from the RTP stream.

        This method is called when a raw data packet is received. It
        processes the packet to extract the audio frame and returns it.
        """
        yield from self.handle_audio_packet(packet, timestamp)

    @property
    def audio_config(self):
        """
        Returns the audio configuration for the audio stream.
        
        Returns:
        ---------
            AudioConfig: The configuration object for the audio stream.
        """
        if self._audio_config is None:
            self._audio_config = self._get_config()        
        return self._audio_config