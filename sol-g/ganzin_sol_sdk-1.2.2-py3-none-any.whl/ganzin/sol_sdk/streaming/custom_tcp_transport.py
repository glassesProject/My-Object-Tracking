import asyncio
from dataclasses import dataclass
from dpkt.rtp import RTP
from functools import partial
from struct import unpack
from time import time
import traceback

from aiortsp.rtsp.errors import RTSPError
from aiortsp.transport.tcp import TCPTransport
from aiortsp.rtcp.parser import RTCP, SR, RTCP_TYPES
from aiortsp.rtcp.stats import RTCPStats
from aiortsp.rtsp.parser import RTSPBinary


TS_OFFSET_1900_MS = 2208988800000
"""
@private
Offset in milliseconds between the NTP epoch (1900-01-01) and the Unix epoch (1970-01-01)
"""

def _ntp_to_ts_ms(seconds: int, fraction: int) -> float:
    """
    Convert NTP seconds and fraction to a timestamp in milliseconds.

    Args:
        seconds (int): The seconds part of the NTP timestamp.
        fraction (int): The fractional part of the NTP timestamp.

    Returns:
        float: The corresponding timestamp in milliseconds, adjusted for the NTP epoch offset.
    """
    ntp_ms = (seconds + fraction / 0x100000000) * 1000
    return ntp_ms - TS_OFFSET_1900_MS

def _sr_unpack_ntp_ts_in_ms(px, pt, p_len, data):
    """
    Unpack an RTCP Sender Report packet and convert NTP timestamps to milliseconds.
    """
    ssrc, ntp1, ntp2, rtp_ts, pkt_count, byte_count = unpack('!IIIIII', data[:24])
    ntp_ts = _ntp_to_ts_ms(ntp1, ntp2)
    reports = SR.parse_reports(px, data[24:])
    return SR(ssrc=ssrc, ntp=ntp_ts, ts=rtp_ts, pkt_count=pkt_count, byte_count=byte_count, reports=reports)

def _custom_rtcp_unpack(data: bytes) -> 'RTCP':
    """
    Parse a buffer into an RTCP instance
    """
    packets = []

    # Iterate on every packet found
    while data:

        # Unpack the header before deciding type
        px, pt, p_len = unpack('!BBH', data[:4])

        # Check version
        if px & 0xC0 != 0x80:
            raise ValueError('RTP version must be 2')

        # Check type exists
        if pt not in RTCP_TYPES:
            raise ValueError(f'Not an RTCP packet type: {pt}')

        # Split current bytes and bytes from next packet
        payload_length = 4 + p_len * 4
        if payload_length > len(data):
            raise ValueError(f'RTCP Packet truncated ({payload_length} > {len(data)})')

        payload, data = data[4:payload_length], data[payload_length:]

        if px & 0x20:
            # There is some padding to be removed
            payload = payload[:len(payload)-payload[-1]]

        if RTCP_TYPES[pt] is SR:
            packets.append(_sr_unpack_ntp_ts_in_ms(px, pt, p_len, payload))
        else:
            # Compound packet, unpack it
            packets.append(RTCP_TYPES[pt].unpack(px, pt, p_len, payload))

    return RTCP(packets=packets)

class CustomTCPTransport(TCPTransport):
    """
    Key modifications to the base class include:
    - Removed interleaved header check on SETUP response.
    - Support interleaved TCP channel:
      - Added support for multiple RTCPStats using interleaved_stats.
      - Ensured each track has a corresponding rtcp_loop and timeout_loop.
    """

    def __init__(self, *args, **kwargs):
        try:
            super().__init__(*args[:-1], **kwargs)
            self.track_number = args[1]
            self.channel_mappings = []
            self.interleaved_stats = [RTCPStats(idx) for idx in range(self.track_number)]
            self._rtcp_loops = [None] * self.track_number
            self._timeout_loops = [None] * self.track_number

        except Exception as ex:
            print(f"Error occur: {ex}")

    @dataclass
    class MediaTrackChannelMapping:
        rtp_idx: int
        rtcp_idx: int

    async def prepare(self):
        for track_id in range(self.track_number):
            rtp_handler = partial(self.handle_rtp_bin, track_id=track_id)
            rtp_idx = self.connection.register_binary_handler(rtp_handler)
            rtcp_handler = partial(self.handle_rtcp_bin, track_id=track_id)
            rtcp_idx = self.connection.register_binary_handler(rtcp_handler)
            channel_mapping = self.MediaTrackChannelMapping(rtp_idx, rtcp_idx)
            self.channel_mappings.append(channel_mapping)
        
            self.logger.info(
                'receiving interleaved RTP (%s) and RTCP (%s)',
                self.channel_mappings[track_id].rtp_idx,
                self.channel_mappings[track_id].rtcp_idx
            )

    def handle_rtcp_bin(self, binary: RTSPBinary, track_id):
        """
        Handle interleaved data registered as RTCP
        """
        self.handle_rtcp_data(binary.data, track_id)

    def handle_rtp_bin(self, binary: RTSPBinary, track_id):
        """
        Handle interleaved data registered as RTP
        """
        self.handle_rtp_data(binary.data, track_id)

    def on_transport_request(self, headers: dict, track_id):
        headers['Transport'] = f'RTP/AVP/TCP;unicast;interleaved={self.channel_mappings[track_id].rtp_idx}-{self.channel_mappings[track_id].rtcp_idx}'

    def on_transport_response(self, headers: dict):
        if 'transport' not in headers:
            raise RTSPError('error on SETUP: Transport not found')
        
        # fields = self.parse_transport_fields(headers['transport'])
        # assert fields.get('interleaved') == f'{self.rtp_idx}-{self.rtcp_idx}', 'invalid returned interleaved header'
    
    async def send_rtcp_report(self, rtcp: RTCP, track_id):
        self.connection.send_binary(self.channel_mappings[track_id].rtcp_idx, bytes(rtcp))

    def handle_rtcp_data(self, data: bytes, track_id):
        """
        Overrides the default RTCP handling to obtain NTP timestamps in milliseconds.
        """
        rtcp = _custom_rtcp_unpack(data)
        self.logger.debug('received RTCP report: %s', rtcp)

        self.interleaved_stats[track_id].handle_rtcp(rtcp)

        # Ganzin: The server does not process RTCP reports, so we intentionally
        # do not start the RTCP loop here.
        # if self._rtcp_loops[track_id] is None:
        #     # This is the first packet ever!
        #     self._rtcp_loops[track_id] = asyncio.ensure_future(self.rtcp_loop(track_id))

        for client in self.clients:
            try:
                client.handle_rtcp(rtcp, track_id)
            except Exception as ex:  # pylint: disable=broad-except
                self.logger.error('error on RTCP client callback: %r', ex)

    def handle_rtp_data(self, data: bytes, track_id):
        """
        An RTP packet was received.
        """
        rtp = RTP(data)

        self.interleaved_stats[track_id].update(rtp)

        for client in self.clients:
            try:
                client.handle_rtp(rtp, track_id)
            except Exception as ex:  # pylint: disable=broad-except
                self.logger.error('error on RTP client callback: %r', ex)

    async def rtcp_loop(self, track_id):
        """
        Handling report sending and timeout
        """
        initial = True
        while self.running:
            delay = self.interleaved_stats[track_id].rtcp_interval(initial)
            initial = False
            self.logger.debug('sleeping for RTCP delay: %s', delay)
            await asyncio.sleep(delay)

            try:
                rtcp = self.interleaved_stats[track_id].build_rtcp()

                if not rtcp:
                    self.logger.warning('no RTCP report available yet (are we receiving anything?)')
                    continue
            except Exception as ex:  # pylint: disable=broad-except
                self.logger.error('unable to build RTCP report: %r', ex)
                traceback.print_exc()
                continue

            try:
                self.logger.debug('sending RTCP report: %s', rtcp)
                await self.send_rtcp_report(rtcp, track_id)
            except asyncio.CancelledError:
                break
            except Exception as ex:  # pylint: disable=broad-except
                self.logger.error('unable to send RTCP report: %r', ex)

    async def timeout_loop(self, track_id):
        """
        Handling report sending and timeout
        """

        sleep_duration = self.timeout
        while self.running:
            await asyncio.sleep(sleep_duration)

            # Check if (and when) we received anything
            diff = time() - self.interleaved_stats[track_id].last_received

            if not self.paused and diff > self.timeout:
                self.logger.error('(Custom) no RTP received for %s seconds: closing. channel=%s', self.timeout, track_id)
                return self.close(TimeoutError('no data'))

            sleep_duration = max(self.timeout - diff, 1)
    
    def close(self, error=None):
        """
        Called when transport needs closing
        """
        if not self.result.done():
            if error:
                self.result.set_exception(error)
            else:
                self.result.set_result(False)

        if self._rtcp_loops:
            for task in filter(None, self._rtcp_loops):
                task.cancel()
            self._rtcp_loops.clear()

        if self._timeout_loops:
            for task in self._timeout_loops:
                if not task.done():
                    task.cancel()
            self._timeout_loops.clear()

        for client in self.clients:
            try:
                client.handle_closed(error)
            except Exception as ex:  # pylint: disable=broad-except
                self.logger.error('error on RTP client callback: %r', ex)

    async def warmup(self, track_id):
        """
        Called before playing.
        Whatever should be done before playing should be done here.
        """
        if self.timeout:
            self._timeout_loops[track_id] = asyncio.ensure_future(self.timeout_loop(track_id))
