from enum import IntFlag


class MediaType(IntFlag):
    """
    Enum representing media types transferred in an RTSP stream.

    Specifies the kinds of data (e.g., audio, video) being transferred in an RTSP stream.
    Multiple media types can be combined in a single stream.
    """
    NOTHING = 0
    AUDIO = 1 << 0
    """ Stream contains only audio data. """
    VIDEO = 1 << 1
    """ Stream contains only video data. """    
    OTHER = 1 << 2
    AUDIO_VIDEO = AUDIO | VIDEO
    """ Stream contains both audio and video data. """
    