from enum import Enum

from .base_stream import BaseStream
from .media_type import MediaType
from dataclasses import dataclass
import struct

# Fields don't follow Python naming conventions to match server data,
# ensuring JSON parsing doesn't fail.
@dataclass
class RawGazeData:
    """
    Dataclass representing raw gaze data.
    """
    combinedSceneCamGazeValidity: bool
    """ Indicates whether the gaze on the 2D image is valid. This is equivalent to `combinedGazeValidity`. """
    combinedSceneCamGazePositionX: float
    """ The gaze position x on the 2d image (from scene camera), measured in pixels. """
    combinedSceneCamGazePositionY: float
    """ The gaze position y on the 2d image (from scene camera), measured in pixels. """
    combinedGazeValidity: bool
    """ Indicates the validity of the combined gaze of both eyes. """
    combinedGazePositionX: float
    """ The x-coordinate of the combined gaze in 3D space, measured in millimeters. """
    combinedGazePositionY: float
    """ The y-coordinate of the combined gaze in 3D space, measured in millimeters. """
    combinedGazePositionZ: float
    """ The z-coordinate of the combined gaze in 3D space, measured in millimeters. """
    leftEyeConfidence: float
    """ The confidence of the left eye's gaze. """
    leftEyeGazeValidity: bool
    """ Indicates the validity of the left eye's gaze.
    It is derived from the confidence value.
    True if confidence exceeds the threshold. """
    leftEyeGazeOriginX: float
    """ The x-coordinate of the left eye's gaze origin in 3D space, measured in millimeters. """
    leftEyeGazeOriginY: float
    """ The y-coordinate of the left eye's gaze origin in 3D space, measured in millimeters. """
    leftEyeGazeOriginZ: float
    """ The z-coordinate of the left eye's gaze origin in 3D space, measured in millimeters. """
    leftEyeGazeDirectionX: float
    """ The x-dimension of the left eye’s gaze direction unit vector. """
    leftEyeGazeDirectionY: float
    """ The y-dimension of the left eye’s gaze direction unit vector. """
    leftEyeGazeDirectionZ: float
    """ The z-dimension of the left eye’s gaze direction unit vector. """
    leftEyeStatus: int
    """
    The status of the left eye. The value can only be one of the following integers:
    - 0: NO_EYE
    - 1: BLINK
    - 2: NORMAL
    """
    leftEyePupil3dValidity: float
    """ The validity of the left eye's pupil in 3D space. """
    leftEyePupil3dDiameter: float
    """ The size of the left eye's pupil in millimeters. """
    leftEyePupil2dPositionX: float
    """ The x-coordinate of the left eye's pupil in 2D space. """
    leftEyePupil2dPositionY: float
    """ The y-coordinate of the left eye's pupil in 2D space. """
    rightEyeConfidence: float
    """ The confidence of the right eye's gaze. """
    rightEyeGazeValidity: bool
    """ Indicates the validity of the right eye's gaze.
    It is derived from the confidence value.
    True if confidence exceeds the threshold. """
    rightEyeGazeOriginX: float
    """ The x-coordinate of the right eye's gaze origin in 3D space, measured in millimeters. """
    rightEyeGazeOriginY: float
    """ The y-coordinate of the right eye's gaze origin in 3D space, measured in millimeters. """
    rightEyeGazeOriginZ: float
    """ The z-coordinate of the right eye's gaze origin in 3D space, measured in millimeters. """
    rightEyeGazeDirectionX: float
    """ The x-dimension of the right eye’s gaze direction unit vector. """
    rightEyeGazeDirectionY: float
    """ The y-dimension of the right eye’s gaze direction unit vector. """
    rightEyeGazeDirectionZ: float
    """ The z-dimension of the right eye’s gaze direction unit vector. """
    rightEyeStatus: int
    """
    The status of the right eye. The value can only be one of the following integers:
    - 0: NO_EYE
    - 1: BLINK
    - 2: NORMAL
    """
    rightEyePupil3dValidity: float
    """ The validity of the right eye's pupil in 3D space. """
    rightEyePupil3dDiameter: float
    """ The size of the right eye's pupil in millimeters. """
    rightEyePupil2dPositionX: float
    """ The x-coordinate of the right eye's pupil in 2D space. """
    rightEyePupil2dPositionY: float
    """ The y-coordinate of the right eye's pupil in 2D space. """

class EyeStatus(Enum):
    """
    Enum representing the eye status.
    """
    NO_EYE = 0
    """ Indicates that no eye can be detected from the given eye image. """
    BLINK = 1
    """
    An experimental value indicating the first occurrence of a sample marked as
    NORMAL following a series of samples marked as NO_EYE, if the duration of
    the NO_EYE series is shorter than a predefined threshold and can be considered
    an eye blink event.
    """
    NORMAL = 2
    """ Indicates whether the eye can be normally detected from the given eye image. """

@dataclass
class GazeData:
    """
    Dataclass representing gaze data.

    Compared to the raw gaze data, this class provides a more structured
    representation of the gaze data.

    For example, to access the gazed position `x` considering data from both eyes, use
    ```python
    data.combined.gaze_2d.x
    ```
    To get the pupil position `x` for only the left eye, use
    ```python
    data.left_eye.pupil2d.x
    ```
    """
    @dataclass
    class Combined:
        """
        Nested dataclass representing combined gaze data.
        """
        @dataclass
        class Gaze2D:
            """ Data for the gaze on the 2D image. """
            validity: bool
            """ Indicates whether the gaze on the 2D image is valid. This is equivalent to `Gaze3D.validity` """
            x: float
            """ The gaze position x on the 2d image (from scene camera), measured in pixels. """
            y: float
            """ The gaze position y on the 2d image (from scene camera), measured in pixels. """

        @dataclass
        class Gaze3D:
            """ Data for the gaze in 3D space. """
            validity: bool
            """ Indicates the validity of the combined gaze of both eyes. """
            x: float
            """ The x-coordinate of the combined gaze in 3D space, measured in millimeters. """
            y: float
            """ The y-coordinate of the combined gaze in 3D space, measured in millimeters. """
            z: float
            """ The z-coordinate of the combined gaze in 3D space, measured in millimeters. """

        gaze_2d: Gaze2D
        """ Data for the gaze on the 2D image. """
        gaze_3d: Gaze3D
        """ Data for the gaze in 3D space. """

    @dataclass
    class Eye:
        """
        Nested dataclass representing per eye data.
        """
        @dataclass
        class Gaze:
            """ Data for per eye gaze. """
            @dataclass
            class Origin:
                """ Data for gaze origin in 3d space. """
                x: float
                """ x-coordinate of the gaze origin in 3d space, measured in millimeters. """
                y: float
                """ y-coordinate of the gaze origin in 3d space, measured in millimeters. """
                z: float
                """ z-coordinate of the gaze origin in 3d space, measured in millimeters. """

            @dataclass
            class Direction:
                """ Data for gaze direction in 3d space. """
                x: float
                """ The x-dimension of the eye’s gaze direction unit vector. """
                y: float
                """ The y-dimension of the eye’s gaze direction unit vector. """
                z: float
                """ The z-dimension of the eye’s gaze direction unit vector. """

            validity: bool
            """ Indicates the validity of the gaze.
            It is derived from the confidence value.
            True if confidence exceeds the threshold. """
            origin: Origin
            """ Origin of the gaze in 3d space. """
            direction: Direction
            """ Direction of the gaze in 3d space. """

        @dataclass
        class Pupil3D:
            """ Data for the pupil in 3d space. """
            validity: float
            """ Validity of the pupil in 3d space. """
            diameter: float
            """ Diameter of the pupil, measured in millimeters. """

        @dataclass
        class Pupil2D:
            """ Data for the pupil in 2d space. """
            x: float
            """ x-coordinate of the pupil in 2d space, measured in pixels. """
            y: float
            """ y-coordinate of the pupil in 2d space, measured in pixels. """

        confidence: float
        """ Confidence of the per eye gaze. """
        eye_status: EyeStatus
        """ Eye status of the per eye gaze. """
        gaze: Gaze
        """ Data for the per eye gaze. """
        pupil3d: Pupil3D
        """ Data for the pupil in 3d space. """
        pupil2d: Pupil2D
        """ Data for the pupil in 2d space. """
    
    combined: Combined
    """ Data for the combined gaze. """
    left_eye: Eye
    """ Data for the left eye. """
    right_eye: Eye
    """ Data for the right eye. """

    timestamp: int
    """
    Unix timestamp in milliseconds. Represents the total number of milliseconds
    elapsed since 00:00:00 UTC on January 1, 1970.
    """

    def from_raw(raw: RawGazeData, timestamp):
        """
        Create a GazeData object from raw gaze data.
        """
        return GazeData(
            GazeData.Combined(
                GazeData.Combined.Gaze2D(raw.combinedSceneCamGazeValidity, raw.combinedSceneCamGazePositionX, raw.combinedSceneCamGazePositionY),
                GazeData.Combined.Gaze3D(raw.combinedGazeValidity, raw.combinedGazePositionX, raw.combinedGazePositionY, raw.combinedGazePositionZ)
            ),
            GazeData.Eye(
                raw.leftEyeConfidence,
                EyeStatus(raw.leftEyeStatus),
                GazeData.Eye.Gaze(
                    raw.leftEyeGazeValidity,
                    GazeData.Eye.Gaze.Origin(raw.leftEyeGazeOriginX, raw.leftEyeGazeOriginY, raw.leftEyeGazeOriginZ),
                    GazeData.Eye.Gaze.Direction(raw.leftEyeGazeDirectionX, raw.leftEyeGazeDirectionY, raw.leftEyeGazeDirectionZ)
                ),
                GazeData.Eye.Pupil3D(raw.leftEyePupil3dValidity, raw.leftEyePupil3dDiameter),
                GazeData.Eye.Pupil2D(raw.leftEyePupil2dPositionX, raw.leftEyePupil2dPositionY)
            ),
            GazeData.Eye(
                raw.rightEyeConfidence,
                EyeStatus(raw.rightEyeStatus),
                GazeData.Eye.Gaze(
                    raw.rightEyeGazeValidity,
                    GazeData.Eye.Gaze.Origin(raw.rightEyeGazeOriginX, raw.rightEyeGazeOriginY, raw.rightEyeGazeOriginZ),
                    GazeData.Eye.Gaze.Direction(raw.rightEyeGazeDirectionX, raw.rightEyeGazeDirectionY, raw.rightEyeGazeDirectionZ)
                ),
                GazeData.Eye.Pupil3D(raw.rightEyePupil3dValidity, raw.rightEyePupil3dDiameter),
                GazeData.Eye.Pupil2D(raw.rightEyePupil2dPositionX, raw.rightEyePupil2dPositionY)
            ),
            timestamp = timestamp
        )

    def get_timestamp(self):
        """
        Returns the Unix timestamp of the gaze data, representing the total number
        of milliseconds elapsed since 00:00:00 UTC on January 1, 1970.
        """
        return self.timestamp

class GazeStream(BaseStream):
    """
    Class for handling gaze data from RTSP streams.
    """

    def __init__(self, *args, **kwargs):
        self._requested_media = MediaType.OTHER
        super().__init__(*args, **kwargs, media_types = { 0: "application" })

    def handle_raw_data(self, packet, timestamp, track_id):
        """
        @private
        Processes raw data and decodes it into gaze data.
        
        The function attempts to unpack the raw byte data using a predefined format string.
        If successful, it creates a RawGazeData object from the unpacked data and converts it
        into a GazeData object using the provided timestamp. If any error occurs during the
        unpacking or processing, it prints an error message and re-raises the exception.

        Arguments:
        ----------
            - data (bytes): The raw byte data to be processed.
            - timestamp: The timestamp associated with the raw data.

        Returns:
        ----------
            GazeData: The decoded gaze data.

        Raises:
        ----------
            Exception: If the data cannot be unpacked or processed.
        """
        try:
            unpacked_data = struct.unpack('!bddbddddbddddddbbddddbddddddbbddd', packet.data)
            raw = RawGazeData(*unpacked_data)
            yield GazeData.from_raw(raw, timestamp)
        except Exception as e:
            print(f'Failed to unpack gaze data: {e}.')
            raise e
