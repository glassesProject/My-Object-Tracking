from dataclasses import dataclass


@dataclass
class AudioConfig:
    """
    Represents the configuration of an audio stream.

    This class is used to encapsulate the audio configuration parameters,
    including the number of channels and the sample rate.
    """
    num_channels: int
    """
    The number of channels in the audio stream.
    """
    sample_rate: int
    """
    The sample rate of the audio stream in Hz.
    """