import av
import base64
from struct import unpack

from .video_frame import VideoFrame


class VideoMixin:
    def handle_video_packet(self, packet, timestamp):
        if not self._video_codec:
            try:
                self._video_media_info = self.get_media("video")
                self._video_codec = self._create_video_codec()
                for param in self._get_sprop_parameters():
                    self._video_codec.parse(param)
            except (KeyError, IndexError) as error:
                yield None
        else:
            for pkt in self._video_codec.parse(self._get_nal_payload(packet.data)):
                for frame in self._video_codec.decode(pkt):
                    yield VideoFrame(frame, timestamp)

    def _create_video_codec(self):
        return av.CodecContext.create(self._get_video_encoding(), "r")

    def _get_video_encoding(self):
        if self._video_encoding is None:
            self._video_encoding = self._video_media_info["attributes"]["rtpmap"]["encoding"].lower()
        return self._video_encoding

    def _get_sprop_parameters(self):
        if self._video_sprop_parameters is None:
            parameter_sets = self._video_media_info["attributes"]["fmtp"]["sprop-parameter-sets"]
            parts = [part for part in parameter_sets.split(",")]
            param_sets = [base64.b64decode(part) for part in parts]
            self._video_sprop_parameters = [self._get_nal_payload(param) for param in param_sets]
        return self._video_sprop_parameters

    def _get_nal_payload(self, data):
        start_bytes = b'\x00\x00\x00\x01'

        payload_header = unpack('!B', data[:1])[0]
        is_forbidden_bit_one = payload_header & 0b10000000
        if is_forbidden_bit_one:
            raise Exception('Forbidden_zero_bit not zero')
        
        payload_offset = 0
        nal_unit_type = payload_header & 0b00011111
        if nal_unit_type == 28:
            payload_offset = 2
            fu_header = unpack('!B', data[1:2])[0]
            if fu_header & 0b10000000:
                p1 = payload_header & 0b11000000
                p2 = fu_header & 0b00011111
                return start_bytes + bytes((p1 + p2, )) + data[payload_offset:]
            else:
                return data[payload_offset:]
                
        return start_bytes + data[payload_offset:]