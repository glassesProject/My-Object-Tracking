import asyncio
from time import time
from urllib.parse import urlparse

from aiortsp.rtsp.reader import RTSPReader
from aiortsp.transport.udp import UDPTransport
from aiortsp.rtsp.session import sanitize_rtsp_url
from dpkt.rtp import RTP
from .media_type import MediaType
from .custom_rtsp_connection import CustomRTSPConnection
from .custom_rtsp_media_session import CustomRTSPMediaSession
from .custom_tcp_transport import CustomTCPTransport


class CustomRTSPReader(RTSPReader):
    """
    Custom RTSP Reader that uses a custom RTSP connection and transport.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.media_type = kwargs.get('media_type', 'video')

    def handle_rtp(self, rtp: RTP, track_id):
        """
        Override the handle_rtp function to remove the filtering of RTP packets 
        based on payload type. This modification ensures that packets of all
        payload types are processed without any restrictions.
        """

        """Queue packets for the iterator"""
        self.queue.put_nowait((rtp, track_id))

    def transport_for_scheme(self, scheme: str):
        """Return transport type based on scheme"""
        transport_class = {
            'rtsp': UDPTransport,
            'rtspt': CustomTCPTransport
        }.get(scheme)

        if not transport_class:
            raise ValueError(f'invalid URL scheme `{scheme}`')

        return transport_class

    async def run_stream(self):
        """
        Setup and play stream, and ensure it stays on.
        """
        self.logger.info('try loading stream %s', sanitize_rtsp_url(self.media_url))

        p_url = urlparse(self.media_url)
        async with CustomRTSPConnection(
                p_url.hostname, p_url.port or 554,
                p_url.username, p_url.password,
                logger=self.logger, timeout=self.timeout
        ) as conn:
            self.logger.info('connected!')

            transport_class = self.transport_for_scheme(p_url.scheme)

            media_track_number = self.count_media_track()
            async with transport_class(conn, media_track_number, logger=self.logger, timeout=self.timeout) as transport:
                sessions = self.create_requested_medias(conn, transport)
                if len(sessions) in (1, 2):
                    await self.manage_streams(conn, transport, sessions)
                else:
                    raise ValueError(f"Invalid number of sessions: {len(sessions)}")

    def count_media_track(self):
        count = 0
        if self._requested_media & MediaType.AUDIO:
            count += 1
            
        if self._requested_media & MediaType.VIDEO:
            count += 1
            
        if self._requested_media & MediaType.OTHER:
            count += 1

        return count

    def create_requested_medias(self, conn, transport):
        sessions = []
        if self._requested_media & MediaType.AUDIO:
            sessions.append(
                CustomRTSPMediaSession(conn, self.media_url, transport=transport,
                                media_type='audio',
                                logger=self.logger)
            )
        if self._requested_media & MediaType.VIDEO:
            sessions.append(
                CustomRTSPMediaSession(conn, self.media_url, transport=transport,
                                media_type='video',
                                logger=self.logger)
            )
        if self._requested_media & MediaType.OTHER:
            sessions.append(
                CustomRTSPMediaSession(conn, self.media_url, transport=transport,
                                logger=self.logger)
            )
        return sessions

    async def manage_streams(self, conn, transport, sessions):
        try:
            primary_session = sessions[0]
            await primary_session.options_describe()
            await primary_session.setup(0)

            """
            You can derive the following concept from RFC 2326:
            If multiple streams are part of the same presentation, each stream
            must be set up using a separate SETUP request. However, all streams
            within a presentation group MUST share the same session identifier
            to ensure they are treated as part of a single logical session.
            """
            other_sessions = sessions[1:]
            for track_id, session in enumerate(other_sessions, start=1):
                session.session_id = primary_session.session_id
                await session.setup(track_id, primary_session.sdp,
                                    primary_session.session_options)

            self.on_ready(conn, transport, primary_session)
            await primary_session.play()

            try:
                last_keep_alive = time()
                while conn.running and transport.running:
                    # Check keep alive (only need to keep alive one session)
                    now = time()
                    if (now - last_keep_alive) > primary_session.session_keepalive:
                        await primary_session.keep_alive()
                        last_keep_alive = now
                        
                    await asyncio.sleep(1)
            
            except asyncio.CancelledError:
                self.logger.info('stopping streams...')
                raise

        finally:
            # Clean up resources
            self.logger.info('tearing down sessions...')
            for session in sessions:
                await session.teardown()