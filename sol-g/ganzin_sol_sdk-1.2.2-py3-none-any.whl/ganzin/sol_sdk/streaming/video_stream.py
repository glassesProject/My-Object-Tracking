from .base_stream import BaseStream
from .media_type import MediaType
from .video_mixin import VideoMixin


class VideoStream(BaseStream, VideoMixin):
    """
    Represents a video stream.

    This class is used to handle the video stream, including
    processing the raw data packets.
    """
    def __init__(self, *args, **kwargs):
        self._video_media_info = None
        self._video_codec = None
        self._video_encoding = None
        self._video_sprop_parameters = None
        self._timestamp = None
        self._requested_media = MediaType.VIDEO
        super().__init__(*args, **kwargs)

    def handle_raw_data(self, packet, timestamp, track_id):
        """
        Handles raw data packets from the RTP stream.
        This method is called when a raw data packet is received. It
        processes the packet to extract the video frame and returns it.
        """
        yield from self.handle_video_packet(packet, timestamp)