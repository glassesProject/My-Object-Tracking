from abc import ABC, abstractmethod
from aiortsp.rtcp.parser import SR
from .custom_rtsp_reader import CustomRTSPReader
from dpkt.rtp import RTP

class RtcpInfo:
    """
    @private
    Class to store information from an RTCP packet, including NTP and RTP timestamps.
    """
    def __init__(self, ntp_ts, rtp_ts):
        self.ntp_ts = ntp_ts
        self.rtp_ts = rtp_ts

class BaseStream(CustomRTSPReader, ABC):
    """
    Base class for handling raw data from RTSP streams.

    This class extends RTSPReader to provide a framework for processing
    RTSP streams. It handles RTCP packets to adjust timestamps and 
    provides an abstract method for handling raw data.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.media_types = kwargs.pop("media_types", { 0: "video"} )
        self.track_count = len(self.media_types)
        self._rtcp_info = [None] * self.track_count

    def handle_rtcp(self, rtcp, track_id):
        """
        Handle incoming RTCP packets.

        Arguments:
        ----------
            rtcp: The RTCP packet containing multiple sub-packets.

        This method iterates over the sub-packets in the RTCP packet and if it finds
        a Sender Report (SR) packet, it records the timestamp difference.
        """
        for pkt in rtcp.packets:
            if isinstance(pkt, SR):
                self._store_rtcp_info(pkt, track_id)

    async def get_data(self):
        """
        Asynchronously get data packets from the RTSP stream.

        This method iterates over the packets in the RTSP stream, adjusts their timestamps,
        and yields the processed data.

        Yields:
        -------
            The processed data with adjusted timestamps.
        """
        async for (pkt, track_id) in self.iter_packets():
            timestamp = self._get_adjusted_timestamp(pkt, track_id)
            if timestamp is None:
                continue

            for data in self.handle_raw_data(pkt, timestamp, track_id):
                if data is not None:
                    yield data
    
    @abstractmethod
    def handle_raw_data(self, packet: RTP, timestamp, track_id):
        """
        Abstract method to handle raw data.

        Arguments:
        ----------
            - packet: RTP packet.
            - timestamp: The adjusted timestamp for the data.
            - track_id: The ID of the media track.

        This method must be implemented by subclasses to process the raw data.
        """
        pass

    def _store_rtcp_info(self, pkt, track_id):
        self._rtcp_info[track_id] = RtcpInfo(ntp_ts=pkt.ntp, rtp_ts=pkt.ts)

    def _get_adjusted_timestamp(self, pkt, track_id):
        if self._rtcp_info[track_id] is None:
            return None
        else:
            return self._get_rtp_timestamp_ms(pkt, track_id)
        
    def _get_rtp_timestamp_ms(self, pkt, track_id):
        dt =  pkt.ts - self._rtcp_info[track_id].rtp_ts
        media = self.get_media(self.media_types[track_id])
        clock_rate = media["attributes"]["rtpmap"]["clockRate"]
        timestamp = (dt / clock_rate) * 1000 + self._rtcp_info[track_id].ntp_ts
        return int(timestamp)

    def get_media(self, media_type):
        """
        Get the media information from the SDP for a specific media type.

        Arguments:
        ----------
            media_type (str): The type of media (e.g., "video", "audio").

        Returns:
        -------
            dict: The media information from the SDP.
        """
        return next(
            (
                item for item in self.session.sdp["medias"]
                if item["type"] == media_type
            ),
            None
        )