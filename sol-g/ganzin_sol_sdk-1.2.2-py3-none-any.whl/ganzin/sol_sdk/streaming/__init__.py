"""
This package includes classes for various types of streams used in the SDK.
"""

__all__ = ['audio_stream', 'video_stream', 'av_stream', 'gaze_stream', 'base_stream',
           'audio_frame', 'video_frame',
           'audio_config']
