import json
from aiortsp.rtsp.session import RTSPMediaSession
from .custom_sdp import CustomSDP

"""
Override the default RTSPMediaSession class to correctly handle custom SDP parsing.
"""
class CustomRTSPMediaSession(RTSPMediaSession):
    async def options_describe(self):
        """
        Perform OPTIONS and DESCRIBE
        """
        # Get supported options
        resp = await self._send('OPTIONS', url=self.media_url)
        self.save_options(resp)

        # Get SDP
        resp = await self._send('DESCRIBE', headers={
            'Accept': 'application/sdp'
        })

        if 'content-base' in resp.headers:
            self.media_url = resp.headers['content-base']
            self.logger.info('using base url: %s', self.media_url)

        self.logger.debug('received SDP:\n%s', resp.content)
        self.sdp = CustomSDP(resp.content)
        self.logger.debug('parsed SDP:\n%s', json.dumps(self.sdp, indent=2))

    async def setup(self, track_id, sdp=None, session_options=None):
        """
        Perform SETUP
        """
        if sdp:
            self.sdp = sdp
        if session_options:
            self.session_options = session_options

        setup_url = self.sdp.setup_url(self.media_url, media_type=self.media_type)
        self.logger.info('setting up using URL: %s', setup_url)

        # --- SETUP <url> RTSP/1.0 ---
        headers = {}
        self.transport.on_transport_request(headers, track_id)
        resp = await self.connection.send_request('SETUP', url=setup_url, headers=headers)
        self.transport.on_transport_response(resp.headers)
        self.logger.info('stream correctly setup: %s', resp)

        # Store session ID
        self.save_session(resp)

        # Warm up transport
        await self.transport.warmup(track_id)