from aiortsp.rtsp.connection import RTSPConnection
from .custom_rtsp_parser import CustomRTSPParser


class CustomRTSPConnection(RTSPConnection):
    """
    Custom RTSP connection that uses a custom parser.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Override the default parser with our custom parser.
        self.parser = CustomRTSPParser()
