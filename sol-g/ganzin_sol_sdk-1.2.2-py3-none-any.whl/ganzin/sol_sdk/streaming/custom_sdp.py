import re
from aiortsp.rtsp.sdp import SDP

"""
Override the default SDP parser class to correctly handle SDP rtpmap attributes.

The original implementation incorrectly parsed complex rtpmap lines with the format:
"rtpmap:<pt> <encoding>/<clockRate>[/<channels>]"

This override ensures:
1. Proper separation of encoding name from clockRate (stops at the first '/')
2. Correct extraction of optional channels parameter when present
3. Consistent handling of media attributes according to RFC 4566

Without this override, rtpmap lines with multiple '/' characters 
(e.g., "rtpmap:97 mpeg4-generic/24000/2") would result in incorrectly
merged encoding+clockRate values and missing channels information.
"""
class CustomSDP(SDP):
    def _parse_attributes(self, value):
        # Attributes are a=<attrname>:<specific content>
        attr, content = value.split(':', 1) if ':' in value else (value, None)
        attributes = self._element.setdefault('attributes', {})

        # # Special cases
        if attr == 'framerate':
            # Content is a framerate as float
            content = float(content)
        elif attr == 'framesize':
            pt, width, height = re.match(r"^ *(\d+) *(\d+)-(\d+) *$", content).groups()
            content = {
                'pt': int(pt),
                'width': int(width),
                'height': int(height)
            }
        elif attr == 'rtpmap':
            pt, enc, clock, channels =  re.match(r"^ *(\d+) +([^\s/]+)/(\d+)(?:/(\d+))? *$", content).groups()
            content = {
                'pt': int(pt),
                'encoding': enc,
                'clockRate': int(clock)
            }
            if channels:
                content['channels'] = int(channels)
        elif attr == 'fmtp':
            pt, opts = content.split(None, 1)
            content = {
                'pt': int(pt)
            }
            for opt in opts.split(';'):
                if not opt.strip():
                    # Empty, probably a wrong semicolon at the end...
                    continue
                k, v = opt.split('=', 1)
                content[k.strip()] = v.strip()

        attributes[attr] = content