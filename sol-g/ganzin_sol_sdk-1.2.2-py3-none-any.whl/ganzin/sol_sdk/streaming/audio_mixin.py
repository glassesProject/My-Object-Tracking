import av
from .audio_config import AudioConfig
from .audio_frame import AudioFrame


class AudioMixin:
    def __init__(self, *args, **kwargs):        
        super().__init__(*args, **kwargs)
        self._audio_media_info = None

    @property
    def audio_media_info(self):
        if self._audio_media_info is None:
            self._audio_media_info = self.get_media("audio")
        return self._audio_media_info

    def handle_audio_packet(self, packet, timestamp):
        if not self._audio_codec:
            try:
                self._audio_codec = self._create_audio_codec()
                self._audio_size_length = self._get_size_length()
            except (KeyError, IndexError) as error:
                yield None
        else:
            for frame in self._decode_audio_packet(packet.data):
                yield AudioFrame(frame, timestamp)

    def _decode_audio_packet(self, rtp_data):
        audio_data = self._extract_audio_frame_from_mpeg4_rtp(rtp_data)
        return self._decode_to_audio_frame(audio_data)

    def _extract_audio_frame_from_mpeg4_rtp(self, rtp_data):
        """
        Extracts AAC audio frame from MPEG-4 RTP payload according to RFC 3640.
        
        RFC 3640 - "RTP Payload Format for Transport of MPEG-4 Elementary Streams"
        defines how MPEG-4 audio (like AAC) is packetized in RTP. This function
        parses the AU (Access Unit) headers and extracts the audio frame.
        
        The RTP payload format includes:
        - AU headers length (2 bytes)
        - AU headers section (variable length)
        - Audio data (actual AAC frames)
        """

        au_headers_length_bits = (rtp_data[0] << 8) | rtp_data[1]
        au_headers_length_bytes = (au_headers_length_bits + 7) // 8
        
        # Skip AU headers length field (2 bytes)
        au_headers = rtp_data[2:2+au_headers_length_bytes]        
       
        # Extract frame size from the first AU header
        frame_size = AudioMixin._extract_frame_size(au_headers, self._audio_size_length)
        
        # Get the actual audio data
        data_offset = 2 + au_headers_length_bytes
        return rtp_data[data_offset:data_offset+frame_size]

    def _extract_frame_size(au_headers, size_length):
        """
        Extract frame size from AU headers with flexible size_length.
        
        Parameters:
            au_headers (bytes): The AU headers from the RTP packet
            size_length (int): Size length from SDP
            
        Returns:
            int: The extracted frame size
        """

        # If size fits in a single byte
        if size_length <= 8:
            # Create a mask for the bits: e.g., for 6 bits: 0b111111
            mask = (1 << size_length) - 1
            # Shift right to remove any trailing bits that belong to the index
            right_shift = 8 - size_length
            frame_size = (au_headers[0] >> right_shift) & mask

        # If size spans exactly 2 bytes
        elif size_length <= 16:
            # Bits in second byte
            bits_in_second_byte = size_length - 8
            
            # Extract from first byte (all 8 bits)
            first_byte_contribution = au_headers[0]
            
            # Extract bits from second byte
            mask = (1 << bits_in_second_byte) - 1
            right_shift = 8 - bits_in_second_byte
            second_byte_contribution = (au_headers[1] >> right_shift) & mask
            
            # Combine
            frame_size = (first_byte_contribution << bits_in_second_byte) | second_byte_contribution
        
        # Handle cases where size spans more than 2 bytes
        else:
            raise NotImplementedError("Frame size extraction for > 16 bits not implemented")
            
        return frame_size

    def _decode_to_audio_frame(self, data):
        packet = av.Packet(data)
        for frame in self._audio_codec.decode(packet):
            yield frame

    def _create_audio_codec(self):
        encoding = self._get_audio_encoding()
        if encoding.startswith("aac"):
            codec_context = av.CodecContext.create("aac", "r")
        else:
            codec_context = av.CodecContext.create(encoding, "r")
        codec_context.layout = self._get_audio_layout(self.audio_config.num_channels)
        codec_context.sample_rate = self.audio_config.sample_rate
        return codec_context

    def _get_audio_layout(self, num_channels):
        if num_channels == 1:
            return av.AudioLayout("mono")
        elif num_channels == 2:
            return av.AudioLayout("stereo")
        else:
            raise NotImplementedError(f"Audio layout for {num_channels} channels not implemented")

    def _get_audio_encoding(self):
        return self.audio_media_info["attributes"]["fmtp"]["mode"].lower()

    def _get_size_length(self):
        return int(self.audio_media_info["attributes"]["fmtp"]["SizeLength"])

    def _get_config(self):
        rtpmap = self.audio_media_info["attributes"]["rtpmap"]
        return AudioConfig(rtpmap["channels"], rtpmap["clockRate"])