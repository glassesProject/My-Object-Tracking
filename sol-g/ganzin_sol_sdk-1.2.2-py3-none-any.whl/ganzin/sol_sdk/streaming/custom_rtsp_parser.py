from typing import Iterator

from aiortsp.rtsp.parser import RTSPParser
from aiortsp.rtsp.parser import RTSPMessage, RTSPRequest, RTSPResponse, RTSPBinary

CRLF = b'\r\n'

class CustomRTSPParser(RTSPParser):
    """
    Custom RTSP parser that removes the data length check from the original parser.
    """
    def __init__(self):
        super().__init__()

    # The data length check has been removed from the original implementation.
    def parse(self, data: bytes) -> Iterator[RTSPMessage]:
        """
        Parse received data into RTSP messages.

        Args:
            data: The raw data received from the RTSP connection.

        Returns:
            A list of RTSP messages parsed from the data.
        """
        while data:
            if self.pending_msg is None:
                # Prepend potential leftover from previous data
                data, self._prev_data = self._prev_data + data, b''

                # We need to determine what is coming next
                if data.startswith(CRLF):
                    # Skip empty lines between items
                    data = data[2:]
                    continue

                if data.startswith(b'RTSP'):
                    # This is a reply
                    self.pending_msg = RTSPResponse()

                elif data.startswith(b'$'):
                    self.pending_msg = RTSPBinary()

                elif data.startswith(RTSPRequest.CLIENT_REQUESTS) or any(
                        req.startswith(data) for req in RTSPRequest.CLIENT_REQUESTS):
                    self.pending_msg = RTSPRequest()

                # elif len(data) > 13:
                #     # That's the longest client request we could expect...
                #     raise ValueError

                else:
                    # Received only a chunk of message. Should be better next iteration. Store
                    self._prev_data = data
                    break

            data, done = self.pending_msg.feed(data)

            if done:
                yield self.pending_msg
                self.pending_msg = None
