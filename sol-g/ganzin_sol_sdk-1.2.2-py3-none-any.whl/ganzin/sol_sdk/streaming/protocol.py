from enum import Enum

class Protocol(Enum):
    UDP = 'rtsp'
    TCP = 'rtspt'

streaming_scheme = Protocol.TCP.value
