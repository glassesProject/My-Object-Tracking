from dpkt.rtp import RTP

from .audio_mixin import AudioMixin
from .base_stream import BaseStream
from .media_type import MediaType
from .video_mixin import VideoMixin


class AvStream(BaseStream, AudioMixin, VideoMixin):
    """
    Represents an audio/video stream.

    This class is used to handle the audio and video streams, including
    processing the raw data packets and managing the audio and video
    configurations.
    """
    def __init__(self, *args, **kwargs):
        # audio
        self._audio_media_info = None
        self._audio_config = None
        self._audio_codec = None
        self._audio_size_length = None
        self._timestamp = None

        # video
        self._video_media_info = None
        self._video_codec = None
        self._video_encoding = None
        self._video_sprop_parameters = None

        self._is_initialized = False
        self._audio_pt = None
        self._video_pt = None
        self._requested_media = MediaType.AUDIO_VIDEO
        super().__init__(*args, **kwargs, media_types={ 0: "audio", 1: "video" })

    def handle_raw_data(self, packet: RTP, timestamp, track_id):
        """
        Handles raw data packets from the RTP stream.
        This method is called when a raw data packet is received. It
        processes the packet based on its payload type (PT) and
        dispatches it to the appropriate handler (audio or video).
        """
        if not self._is_initialized:
            self._audio_pt = int(self.get_media("audio")["format"])
            self._video_pt = int(self.get_media("video")["format"])
            self._is_initialized = True

        if track_id == 0:
            return self.handle_audio_packet(packet, timestamp)
        elif track_id == 1:
            return self.handle_video_packet(packet, timestamp)
        else:
            raise ValueError(f"Unknown track_id: {track_id}")

    @property
    def audio_config(self):
        """
        Returns the audio configuration for the audio stream.
        
        Returns:
        ---------
            AudioConfig: The configuration object for the audio stream.
        """
        if self._audio_config is None:
            self._audio_config = self._get_config()        
        return self._audio_config