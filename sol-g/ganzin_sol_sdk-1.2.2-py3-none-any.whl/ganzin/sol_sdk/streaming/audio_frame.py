from dataclasses import dataclass

import av
import numpy as np


@dataclass
class AudioFrame:
    """
    Represents an audio frame in an audio stream.

    This class is used to encapsulate the audio data and its associated
    timestamp.
    """
    _frame: av.AudioFrame
    _timestamp: float

    def get_pcm(self):
        """
        Returns the audio samples in PCM format.

        The audio samples are returned as a byte array, where each sample is
        represented as a 32-bit float. The audio samples are interleaved if
        the audio has multiple channels.
        """
        samples = self._frame.to_ndarray()
        # If the audio has multiple channels, they are flattened into
        # a single interleaved byte stream.
        if samples.ndim > 1:
            flattened_samples = np.vstack(samples).T.flatten()
        else:
            flattened_samples = samples.flatten()

        return flattened_samples.astype(np.float32).tobytes()

    def get_timestamp(self):
        """
        Returns the Unix timestamp of the video frame data, representing the
        total number of milliseconds elapsed since 00:00:00 UTC on January 1, 1970.
        """
        return self._timestamp