import base64
from dataclasses import dataclass, fields
import json
from typing import Dict, Optional

from .common_models import ApiStatus
from .streaming.gaze_stream import GazeData, RawGazeData

# Dynamically create the _mapping dictionary by iterating over the provided classes.
# For each class, extract the field names using the dataclasses.fields function.
# Create a frozenset of these field names and use it as the key in the _mapping dictionary.
# The value for each key is the corresponding class itself.
# This is necessary when dealing with nested dataclasses.
def _create_mapping(*classes):
    mapping = {}
    for cls in classes:
        field_names = frozenset(field.name for field in fields(cls))
        mapping[field_names] = cls
    return mapping

# Creates a class instance based on the provided dictionary and the mapping.
def _class_mapper(d: dict, mapping):
    for keys, cls in mapping.items():
        if keys.issubset(d.keys()):  # Check if the dictionary keys contain all required keys.
            filtered_dict = {k: v for k, v in d.items() if k in keys}  # Filter out extra keys.
            return cls(**filtered_dict)
    raise KeyError(f"No mapping found for keys: {frozenset(d.keys())}")

def parse_json_to_object(json_data: str, cls: type) -> object:
    """
    Parses a JSON string and converts it into an instance of the specified class.
    
    Arguments:
    ----------
        - json_data (str): A JSON string representing the data.
        - cls (type): The class type to which the JSON data should be converted.
        
    Returns:
    --------
        object: An instance of the specified class populated with the JSON data.

    Example:
    --------
    ```python
    obj = parse_json_to_object(json_text, TagResponse)
    ```
    """
    data = json.loads(json_data)

    # Get the set of valid field names for the class
    valid_fields = {f.name for f in fields(cls)}

    # Filter out any unexpected fields
    filtered_data = {k: v for k, v in data.items() if k in valid_fields}

    return cls(**filtered_data)

@dataclass
class VersionResponse:
    """
    Represents the response from the version endpoint.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.get_version()
    print(resp.remote_api_version)
    ```
    """
    status: str
    """ The status of the response. """
    remote_api_version: str
    """ The SDK version supported by the server. """

VersionResponse._mapping = _create_mapping(VersionResponse)
def versionResponseMapper(data: dict):
    """
    @private
    Maps the provided dictionary to a VersionResponse object.
    """
    return _class_mapper(data, VersionResponse._mapping)

@dataclass
class PhoneStorageInfo:
    """
    Represents the storage information of the phone.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.get_status()
    print(resp.phone_storage_info.free_storage_byte)
    ```
    """
    free_storage_byte: int
    """ The amount of free storage in bytes. """
    total_storage_byte: int
    """ The total storage capacity in bytes. """

@dataclass
class StatusResponse:
    """
    Represents the response from the status endpoint.
    
    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.get_status()
    print(resp.device_name)
    ```
    """
    status: str
    """ The status of the response. """
    ip: str
    """ The IP address of the device. """
    port: int
    """ The port number of the device. """
    device_name: str
    """ The name of the device. """
    device_battery_percentage: int
    """ The battery percentage of the device. """
    is_screen_locked: bool
    """ Indicates whether the screen is locked. """
    is_recording: bool
    """ Indicates whether the device is currently recording. """
    recording_duration_ns: int
    """ The duration of the recording in nanoseconds. """
    eye_image_encoding_enabled: bool
    """ Indicates whether eye image encoding is enabled. """
    audio_enabled: bool
    """
    Indicates whether audio is enabled for the stream.
    
    When this toggle is on, an audio track will be present in the stream.
    Note: If the toggle is turned on, it may take a few seconds for the audio stream to become ready.
    """
    phone_storage_info: PhoneStorageInfo
    """ The storage information of the phone. """
    is_foreground: bool
    """ Indicates whether the app is running in foreground. """
    recording_start_time_ms: int
    """ The Unix timestamp in milliseconds representing the start time of current recording. """
    missing_data_rate: float
    """ Realtime statistics of how many ratio of eye data are invalid (0.0 ~ 1.0). """
 
StatusResponse._mapping = _create_mapping(StatusResponse, PhoneStorageInfo)
def statusResponseMapper(data: dict):
    """
    @private
    Maps the provided dictionary to a StatusResponse object.
    """
    return _class_mapper(data, StatusResponse._mapping)


@dataclass
class CameraParam:
    """ Camera parameters for calibration and distortion correction. """

    intrinsic: list
    """
    The intrinsic camera matrix, which includes the focal length and optical center.
    It is a 3x3 matrix with the following structure:
    ```python
    [ fx  0  cx ]
    [ 0  fy  cy ]
    [ 0   0   1 ]
    ```
    where fx and fy are the focal lengths, and cx and cy are the coordinates of the optical center.
    """

    distort: list
    """
    The distortion coefficients for correcting lens distortion.
    It is a list of five elements:
    ```python
    [k1, k2, p1, p2, k3]
    ```
    where:
    - k1, k2, and k3 are the radial distortion coefficients.
    - p1 and p2 are the tangential distortion coefficients.
    """

@dataclass
class SceneCameraParamResult:
    """ Represents the result of the scene camera parameter retrieval endpoint. """
    camera_param: CameraParam
    """ The camera parameters for the scene camera. """

@dataclass
class SceneCameraParamResponse:
    """
    Represents the response from the scene camera parameter endpoint.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.get_scene_camera_param()
    print(resp.camera_param.intrinsic)
    ```
    """

    status: ApiStatus
    """ The status of the response. """

    message: str
    """ The message of the response. """

    result: SceneCameraParamResult
    """ The retrieved scene camera parameters. """

SceneCameraParamResponse._mapping = _create_mapping(
    SceneCameraParamResponse, SceneCameraParamResult, CameraParam
)
def sceneCameraParamResponseMapper(data: dict):
    """
    @private
    Maps the provided dictionary to a SceneCameraParamResponse object.
    """
    return _class_mapper(data, SceneCameraParamResponse._mapping)

@dataclass
class RecordResponse:
    """
    Represents the response from the record endpoint.
    
    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.begin_record()
    print(resp.status)
    resp = sc.end_record()
    print(resp.status)
    ```
    """
    message: str
    status: str

RecordResponse._mapping = _create_mapping(RecordResponse)
def recordResponseMapper(data: dict):
    """
    @private
    Maps the provided dictionary to a RecordResponse object.
    """
    return _class_mapper(data, RecordResponse._mapping)

@dataclass
class TagResult:
    """
    Represents the result of a tag request. The name and timestamp echo the request.
    """

    name: str
    timestamp: int

@dataclass
class TagResponse:
    """
    Represents the response from the tag endpoint.
    
    Example:
    ```python
    sc = SyncClient(address, port)
    color = TagColor.LightSeaGreen
    req = AddTagRequest('right moment', 'description', 1719387152014, color)
    resp = sc.add_tag(req)
    print(f'Add tag result? {resp}')
    ```
    """
    status: str
    message: str
    result: Optional[TagResult] = None # Contains a value only when tagging is successful.

    def __init__(self, status: str, message: str, result: Optional[Dict] = None):
        self.status = status
        self.message = message
        if isinstance(result, dict):
            self.result = TagResult(**result)
        else:
            self.result = result

@dataclass
class LockResponse:
    """
    Represents the response from the lock endpoint.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.lock()
    print(resp.status)
    resp = sc.unlock()
    print(resp.status)
    ```
    """
    status: str
    message: str

LockResponse._mapping = _create_mapping(LockResponse)
def lockResponseMapper(data: dict):
    """
    @private
    Maps the provided dictionary to a LockResponse object.
    """
    return _class_mapper(data, LockResponse._mapping)

@dataclass
class CaptureRawResult:
    """ Represents the raw result of a capture request. """
    timestamp: int
    """ Unix timestamp in milliseconds. Represents the total number of milliseconds elapsed since 00:00:00 UTC on January 1, 1970. """
    sceneImgBase64: str
    """ The base64-encoded scene camera image. """
    gazeData: RawGazeData
    """ The raw gaze data. """

@dataclass
class CaptureResponse:
    """
    Represents the response from the capture endpoint.
    Please use `CaptureResult` instead, since it makes gaze data more organized.
    """
    status: str
    """ The status of the response. """
    message: str
    """ The message of the response. """
    result: CaptureRawResult
    """ The raw result of the response. It contains the timestamp, scene camera image, and gaze data. """

CaptureResponse._mapping = _create_mapping(CaptureResponse, CaptureRawResult, RawGazeData)
def captureResponseMapper(data: dict):
    """
    @private
    Maps the provided dictionary to a CaptureResponse object.
    """
    return _class_mapper(data, CaptureResponse._mapping)

@dataclass
class CaptureResult:
    """
    Represents the processed result of a capture request, containing the timestamp,
    scene camera image, and gaze data.
    
    Example:
    ----------------
    ```python
    sc = SyncClient(address, port)
    resp = sc.capture()
    result = CaptureResult.from_raw(resp.result)
    print(f'timestamp = {result.timestamp}')
    print(f'gaze: x = {result.gaze_data.combined.gaze_2d.x}, y = {result.gaze_data.combined.gaze_2d.y}')
    with open("image_captured.jpg", "wb") as file:
        file.write(result.scene_image)
        print(f'Saved image to "{file.name}"') 
    ```
    """
    timestamp: int
    """ Unix timestamp in milliseconds. Represents the total number of milliseconds elapsed since 00:00:00 UTC on January 1, 1970. """
    scene_image: bytes
    """ The scene camera image data. """
    gaze_data: GazeData
    """ The gaze data. """

    @classmethod
    def from_raw(cls, source: CaptureRawResult):
        """ Creates a CaptureResult instance from the provided CaptureRawResult object. """
        image = base64.b64decode(source.sceneImgBase64)
        gaze = GazeData.from_raw(source.gazeData, source.timestamp)
        return cls(source.timestamp, image, gaze)
