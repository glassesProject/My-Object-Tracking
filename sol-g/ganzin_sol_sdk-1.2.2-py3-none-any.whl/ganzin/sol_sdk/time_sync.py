import websockets
from websockets import WebSocketClientProtocol
from struct import pack, unpack
from dataclasses import dataclass
import statistics
from .utils import get_timestamp_ms

class TimeSyncStatistics:
    """
    Class to handle time synchronization statistics.

    This class is used to store and process the results of multiple time 
    synchronization polls.
    """
    def __init__(self, data):
        """
        Initializes the TimeSyncStatistics with the specified data
        """
        self._mean = statistics.mean(data)

    @property
    def mean(self):
        """
        Returns the mean of the time synchronization statistics.
        """
        return self._mean

@dataclass
class TimeSyncResult:
    """
    Class to handle the results of time synchronization.
    """
    time_offset: TimeSyncStatistics
    """ The time offset statistics. """
    round_trip: TimeSyncStatistics
    """ The round trip statistics. """

class TimeSync:
    """
    Class to handle time synchronization.

    Example:
    ```python
    import asyncio
    from time_sync import TimeSync
    async def main():
        url = "http://example.com/timesync"
        time_sync = TimeSync(url)
        result = await time_sync.polls_multiple_times(number_of_polls=80)
        print(f"Time Offset Mean: {result.time_offset.mean}")
        print(f"Round Trip Mean: {result.round_trip.mean}")
    asyncio.run(main())
    ```
    """
    def __init__(self, url):
        """
        Initializes the TimeSync with the specified URL.
        """
        self._url = url

    async def polls_multiple_times(self, number_of_polls = 60) -> TimeSyncResult:
        """
        Polls the server multiple times to get time offset and round trip time.
        """
        time_offset_results = list()
        round_trip_results = list()

        async with websockets.connect(self._url) as ws:
            try:
                await self.send_sync_request(ws) # Ignore first result due to potentially expensive startup costs

                for _ in range(number_of_polls):
                    try:
                        time_offset, round_trip = await self.send_sync_request(ws)
                        time_offset_results.append(time_offset)
                        round_trip_results.append(round_trip)
                    except ValueError as err:
                        print(err)
            except Exception as ex:
                print(ex)

            return TimeSyncResult(
                TimeSyncStatistics(time_offset_results),
                TimeSyncStatistics(round_trip_results)
            )

    @staticmethod
    async def send_sync_request(websocket: WebSocketClientProtocol):
        """
        Sends a time synchronization request to the server and returns the time offset and round trip time.
        """
        client_start_time = get_timestamp_ms()
        request = pack("!Q", client_start_time)
        await websocket.send(request)
        resp = await websocket.recv()
        client_end_time = get_timestamp_ms()

        if len(resp) != 16:
            raise ValueError(f'Unexpected response length: {len(resp)}')

        start_time_from_resp, server_time = unpack("!QQ", resp)
        if start_time_from_resp != client_start_time:
            raise ValueError(f'Echoed time mismatched')

        projected_server_time = (client_start_time + client_end_time) / 2
        time_offset = projected_server_time - server_time
        round_trip = client_end_time - client_start_time
        return (round(time_offset), round_trip)
