from dataclasses import dataclass
from enum import StrEnum

class ApiStatus(StrEnum):
    SUCCESS = "SUCCESS",
    FAILED = "FAILED"

class Camera(StrEnum):
    """
    Enum class representing different camera types.
    """

    GAZE = "gaze"
    """
    Represents the gaze camera.
    """

    SCENE = "scene"
    """
    Represents the scene camera.
    """
    
    LEFT_EYE = "left_eye"
    """
    Represents the left eye camera.
    """

    RIGHT_EYE = "right_eye"
    """
    Represents the right eye camera.
    """

@dataclass
class SemanticVersion:
    """
    Dataclass representing a semantic version.
    """

    major: int
    """
    The major version number.
    """

    minor: int
    """
    The minor version number.
    """

    patch: int
    """
    The patch version number.
    """

    def __repr__(self):
        return f"{self.major}.{self.minor}.{self.patch}"