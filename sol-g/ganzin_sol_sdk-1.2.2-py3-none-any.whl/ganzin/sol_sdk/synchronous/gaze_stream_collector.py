import asyncio
import weakref
from ..streaming.gaze_stream import GazeStream


class GazeStreamCollector:
    """
    Class responsible for collecting gaze data.
    """

    def __init__(self, url, data_mgr_ref: weakref.ReferenceType):
        """
        Initializes the GazeStreamCollector with the specified URL and data manager reference.

        Arguments:
        ----------
        - **url** : str
            The URL of the gaze data stream.
        - **data_mgr_ref** : weakref.ReferenceType
            A weak reference to the data manager object, which is used to store the collected gaze data.
        """
        self._url = url
        self._data_mgr = data_mgr_ref
        self._streaming_task = None
        
    def start(self):
        """
        Starts the collection of gaze data.
        """
        self._streaming_task = asyncio.create_task(self._collect_gaze())

    async def _collect_gaze(self):
        self._data_mgr().clear_gaze_store()
        async with GazeStream(self._url) as streamer:
            async for item in streamer.get_data():
                self._data_mgr().add_gaze(item)
