import asyncio
from dataclasses import dataclass
import weakref

from ..streaming.audio_stream import AudioStream


@dataclass
class SceneCameraAudioCollector:
    """
    Class to handle the collection of scene camera audio stream.

    Arguments:
    ----------
    - **url** : str
        The URL of the scene camera stream.
    - **data_mgr** : weakref.ReferenceType
        A weak reference to the data manager object, which is used to store the collected frames.
    - **on_start_callback** : callable
        A callback function that is called when the audio stream starts. It receives the audio configuration as an argument.
    """
    _url: str
    _data_mgr: weakref.ReferenceType
    _on_start_callback: callable

    def start(self):
        """
        Initiates collection of audio stream from the scene camera.
        """
        self._streaming_task = asyncio.create_task(self._collect_data())

    async def _collect_data(self):
        is_first_frame = True
        async with AudioStream(self._url) as stream:
            async for frame in stream.get_data():
                if is_first_frame:
                    self._on_start_callback(stream.audio_config)
                    is_first_frame = False
                data_mgr = self._data_mgr()
                data_mgr.add_audio_frame(frame)