"""
This package contains modules for the synchronous client, which is used to 
interact with the server.
"""