from enum import IntFlag


class StreamingMode(IntFlag):
    """
    Enum class representing different streaming modes using bitwise flags.

    This class uses bitwise flags to represent various combinations of streaming modes.
    Each mode is represented by a unique bit, allowing for combinations of modes using
    bitwise OR operations.

    Examples:
    >>> mode = StreamingMode.GAZE | StreamingMode.SCENE
    >>> mode == StreamingMode.GAZE_SCENE
    True

    >>> mode = StreamingMode.GAZE_SCENE | StreamingMode.EYES
    >>> mode == StreamingMode.GAZE_SCENE_EYES
    True

    >>> mode = StreamingMode.NOTHING
    >>> bool(mode & StreamingMode.GAZE)
    False
    """
    NOTHING = 0
    "Represents no streaming mode."
    GAZE = 1 << 0
    "Represent the gaze streaming mode."
    SCENE = 1 << 1
    "Represent the scene streaming mode."
    EYES = 1 << 2
    "Represent the eyes streaming mode."
    AUDIO = 1 << 3
    "Represent the audio streaming mode."
    AUDIO_VIDEO = 1 << 4
    "Represent the audio and video streaming mode."
    
    GAZE_SCENE = GAZE | SCENE
    "Represents the combination of gaze and scene streaming modes (GAZE | SCENE)."
    GAZE_SCENE_EYES = GAZE | SCENE | EYES
    "Represents the combination of gaze, scene, and eyes streaming modes (GAZE | SCENE | EYES)."
